﻿# -*- coding: utf-8 -*-
import re, urllib, urllib2, os, cookielib, base64, sys, random, math
from urlparse import parse_qs, urlparse, urljoin, urlsplit, urlunsplit
import time
from urllib2 import HTTPError, URLError
import htmlentitydefs
import string
import xbmc
import xbmcgui

UA = 'Mozilla/5.0 TURKvod 8.0'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'
IE_USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
HEADERS = {"User-Agent":FF_USER_AGENT}

def mydebug():
    pass

def compat_ord(c):
    if type(c) is int:
        return c
    else:
        return ord(c)
	
try:
    compat_chr = unichr  # Python 2
except NameError:
    compat_chr = chr
	
try:
    import pafy
    pfy = True
except ImportError:
    pfy = False

def versiyon(parser_ver = '<h1>(.*?)</h1></td>\\W*</tr>\\W*<tr>\\W*<td align="right"><h3>(.*?)</h3></td>\\W*<td align="left"><h2>(.*?)</h2></td>\\W*</tr>\\W*<tr>\\W*<td align="right"><h3>(.*?)</h3></td>\\W*<td align="left"><h2>(.*?)</h2>'):
    return parser_ver

def VSlog(e):
    pass

def unescape(self,text):
    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            try:
                text = unichr(htmlentitydefs.name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return re.sub("&#?\w+;", fixup, text)
    
### aadecode ###################################################
def aadecode(text):
    text = re.sub(r"\s+|/\*.*?\*/", "", text)
    data = text.split("+(ﾟДﾟ)[ﾟoﾟ]")[1]
    chars = data.split("+(ﾟДﾟ)[ﾟεﾟ]+")[1:]

    txt = ""
    for char in chars:
        char = char \
            .replace("(oﾟｰﾟo)","u") \
            .replace("c", "0") \
            .replace("(ﾟДﾟ)['0']", "c") \
            .replace("ﾟΘﾟ", "1") \
            .replace("!+[]", "1") \
            .replace("-~", "1+") \
            .replace("o", "3") \
            .replace("_", "3") \
            .replace("ﾟｰﾟ", "4") \
            .replace("(+", "(")
        char = re.sub(r'\((\d)\)', r'\1', char)

        c = ""; subchar = ""
        for v in char:
            c+= v
            try: x = c; subchar+= str(eval(x)); c = ""
            except: pass
        if subchar != '': txt+= subchar + "|"
    txt = txt[:-1].replace('+','')

    txt_result = "".join([ chr(int(n, 8)) for n in txt.split('|') ])

    return toStringCases(txt_result)

def toStringCases(txt_result):
    sum_base = ""
    m3 = False
    if ".toString(" in txt_result:
        if "+(" in  txt_result:
            m3 = True
            sum_base = "+"+find_single_match(txt_result,".toString...(\d+).")
            txt_pre_temp = find_multiple_matches(txt_result,"..(\d),(\d+).")
            txt_temp = [ (n, b) for b ,n in txt_pre_temp ]
        else:
            txt_temp = find_multiple_matches(txt_result, '(\d+)\.0.\w+.([^\)]+).')
        for numero, base in txt_temp:
            code = toString( int(numero), eval(base+sum_base) )
            if m3:
                txt_result = re.sub( r'"|\+', '', txt_result.replace("("+base+","+numero+")", code) )
            else:
                txt_result = re.sub( r"'|\+", '', txt_result.replace(numero+".0.toString("+base+")", code) )
    return txt_result

def toString(number,base):
    string = "0123456789abcdefghijklmnopqrstuvwxyz"
    if number < base:
        return string[number]
    else:
        return toString(number//base,base) + string[number%base]
### aadecode ###################################################

# unwise ###############################
def unwise1(w):
    int1 = 0
    result = ""
    while int1 < len(w):
        result = result + chr(int(w[int1:int1 + 2], 36))
        int1 += 2
    return result

def unwise(w, i, s, e, wi, ii, si, ei):
    int1 = 0
    int2 = 0
    int3 = 0
    int4 = 0
    string1 = ""
    string2 = ""
    while True:
        if w != "":
            if int1 < wi:
                string2 = string2 + w[int1:int1 + 1]
            elif int1 < len(w):
                string1 = string1 + w[int1:int1 + 1]
            int1 += 1
        if i != "":
            if int2 < ii:
                string2 = string2 + i[int2:int2 + 1]
            elif int2 < len(i):
                string1 = string1 + i[int2:int2 + 1]
            int2 += 1
        if s != "":
            if int3 < si:
                string2 = string2 + s[int3:int3 + 1]
            elif int3 < len(s):
                string1 = string1 + s[int3:int3 + 1]
            int3 = int3 + 1
        if e != "":
            if int4 < ei:
                string2 = string2 + e[int4:int4 + 1]
            elif int4 < len(e):
                string1 = string1 + e[int4:int4 + 1]
            int4 = int4 + 1
        if len(w) + len(i) + len(s) + len(e) == len(string1) + len(string2):
            break
    int1 = 0
    int2 = 0
    result = ""
    while int1 < len(string1):
        flag = -1
        if ord(string2[int2:int2 + 1]) % 2:
            flag = 1
        result = result + chr(int(string1[int1:int1 + 2], 36) - flag)
        int2 += 1
        if int2 >= len(string2):
            int2 = 0
        int1 += 2
    return result

def unwise_process(result):
    while True:
        a = re.compile(r';?eval\s*\(\s*function\s*\(\s*w\s*,\s*i\s*,\s*s\s*,\s*e\s*\).+?[\"\']\s*\)\s*\)(?:\s*;)?').search(result)
        if not a:
            break
        a = a.group()
        tmp = re.compile(r'\}\s*\(\s*[\"\'](\w*)[\"\']\s*,\s*[\"\'](\w*)[\"\']\s*,\s*[\"\'](\w*)[\"\']\s*,\s*[\"\'](\w*)[\"\']').search(a)
        if not tmp:
            result = result.replace(a, "")
        else:
            wise = ["", "", "", ""]
            wise = tmp.groups()
            if a.find("while") == -1:
                result = result.replace(a, unwise1(wise[0]))
            else:
                c = 0
                wisestr = ["", "", "", ""]
                wiseint = [0, 0, 0, 0]
                b = re.compile(r'while(.+?)var\s*\w+\s*=\s*\w+\.join\(\s*[\"\'][\"\']\s*\)').search(a).group(1)
                for d in re.compile(r'if\s*\(\s*\w*\s*\<\s*(\d+)\)\s*\w+\.push').findall(b):
                    wisestr[c] = wise[c]
                    wiseint[c] = int(d)
                    c += 1
                result = result.replace(a, unwise(wisestr[0], wisestr[1], wisestr[2], wisestr[3], wiseint[0], wiseint[1], wiseint[2], wiseint[3]))
    return result

def resolve_var(HTML, key):  # this should probably be located elsewhere
    key = re.escape(key)
    tmp1 = HTML.replace("\r", "")
    tmp1 = tmp1.replace("\n", ";")
    tmp2 = re.compile(r'[^\w\.]' + key + '\s*=\s*([^\"\']*?)[;,]').search(tmp1)  # expect var first, movshare
    if tmp2:
        tmp2 = resolve_var(HTML, tmp2.group(1))
    else:
        tmp2 = re.compile(r'[^\w\.]' + key + '\s*=\s*[\"\'](.*?)[\"\']').search(tmp1)
        if tmp2:
            tmp2 = tmp2.group(1)
        else:
            key = key.split("\\.")
            if len(key) == 2:
                tmp2 = re.compile(r'[^\w\.]' + key[0] + '\s*=\s*\{.*[^\w\.]' + key[1] + '\s*\:\s*[\"\'](.*?)[\"\']').search(tmp1)  # for 'vars = { key: "value" }', cloudy
            if tmp2:
                tmp2 = tmp2.group(1)
            else:
                tmp2 = ""  # oops, should not happen in the variable is valid
    return tmp2
# unwise ###############################

#****************************************************************
#openload *******************************************************
#****************************************************************

class cRequestHandler:
    REQUEST_TYPE_GET = 0
    REQUEST_TYPE_POST = 1
      
    def __init__(self, sUrl):
        self.__sUrl = sUrl
        self.__sRealUrl = ''
        self.__cType = 0
        self.__aParamaters = {}
        self.__aParamatersLine = ''
        self.__aHeaderEntries = []
        self.removeBreakLines(True)
        self.removeNewLines(True)
        self.__setDefaultHeader()
        self.__timeout = 30
        self.__bRemoveNewLines = False
        self.__bRemoveBreakLines = False
        self.__sResponseHeader = ''
        
        self.__HeaderReturn = ''

    def removeNewLines(self, bRemoveNewLines):
        self.__bRemoveNewLines = bRemoveNewLines

    def removeBreakLines(self, bRemoveBreakLines):
        self.__bRemoveBreakLines = bRemoveBreakLines

    def setRequestType(self, cType):
        self.__cType = cType
        
    def setTimeout(self, valeur):
        self.__timeout = valeur    

    def addHeaderEntry(self, sHeaderKey, sHeaderValue):
        for sublist in self.__aHeaderEntries:
            if sHeaderKey in sublist:
                self.__aHeaderEntries.remove(sublist)
        aHeader = {sHeaderKey : sHeaderValue}
        self.__aHeaderEntries.append(aHeader)

    def addParameters(self, sParameterKey, mParameterValue):
        self.__aParamaters[sParameterKey] = mParameterValue
        
    def addParametersLine(self, mParameterValue):
        self.__aParamatersLine = mParameterValue
        
    #egg addMultipartFiled('sess_id':sId,'upload_type':'url','srv_tmp_url':sTmp)
    def addMultipartFiled(self,fields ):
        mpartdata = MPencode(fields)
        self.__aParamaters = mpartdata[1]
        self.addHeaderEntry('Content-Type', mpartdata[0] )
        self.addHeaderEntry('Content-Length', len(mpartdata[1]))

    #Fonction la plus fiable
    def getResponseHeader(self):
        return self.__sResponseHeader
    
    #Ce n'est pas un doublon de getResponseHeader, si il y a des doublon, l'une des deux fonctions les zappe.
    def GetHeaders(self):
        return self.__HeaderReturn
        
    # url after redirects
    def getRealUrl(self):
        return self.__sRealUrl
        
    def GetCookies(self):
        if 'Set-Cookie' in self.__sResponseHeader:
            import re
            
            #cookie_string = self.__sResponseHeader.getheaders('set-cookie')
            #c = ''
            #for i in cookie_string:
            #    c = c + i + ', '
            c = self.__sResponseHeader.getheader('set-cookie')
            
            c2 = re.findall('(?:^|,) *([^;,]+?)=([^;,\/]+?);',c)
            if c2:
                cookies = ''
                for cook in c2:
                    cookies = cookies + cook[0] + '=' + cook[1]+ ';'
                return cookies
        return ''

    def request(self):
        self.__sUrl = self.__sUrl.replace(' ', '+')
        return self.__callRequest()

    def getRequestUri(self):
        return self.__sUrl + '?' + urllib.urlencode(self.__aParamaters)

    def __setDefaultHeader(self):
        self.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0')
        self.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
        self.addHeaderEntry('Accept-Charset', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7')

    def __callRequest(self):
        if self.__aParamatersLine:
            sParameters = self.__aParamatersLine
        else:
            sParameters = urllib.urlencode(self.__aParamaters)

        if (self.__cType == cRequestHandler.REQUEST_TYPE_GET):
            if (len(sParameters) > 0):
                if (self.__sUrl.find('?') == -1):
                    self.__sUrl = self.__sUrl + '?' + str(sParameters)
                    sParameters = ''
                else:
                    self.__sUrl = self.__sUrl + '&' + str(sParameters)
                    sParameters = ''

        if (len(sParameters) > 0):
            oRequest = urllib2.Request(self.__sUrl, sParameters)
        else:
            oRequest = urllib2.Request(self.__sUrl)

        for aHeader in self.__aHeaderEntries:
            for sHeaderKey, sHeaderValue in aHeader.items():
                oRequest.add_header(sHeaderKey, sHeaderValue)

        sContent = ''
        try:
            oResponse = urllib2.urlopen(oRequest, timeout = self.__timeout)
            sContent = oResponse.read()
            
            self.__sResponseHeader = oResponse.info()
            
            #compressed page ?
            if self.__sResponseHeader.get('Content-Encoding') == 'gzip':
                import zlib
                sContent = zlib.decompress(sContent, zlib.MAX_WBITS|16)
                
            self.__sRealUrl = oResponse.geturl()
            self.__HeaderReturn = oResponse.headers
        
            oResponse.close()
            
        except urllib2.HTTPError, e:
            if e.code == 503:
                
                #Protected by cloudFlare ?
                from resources.lib import cloudflare
                if cloudflare.CheckIfActive(e.read()):
 
                    cookies = self.GetCookies()

                    print 'Page protegee par cloudflare'
                    CF = cloudflare.CloudflareBypass()
                    sContent = CF.GetHtml(self.__sUrl,e.read(),cookies,sParameters,oRequest.headers)
                    self.__sRealUrl,self.__HeaderReturn = CF.GetReponseInfo()

            if not sContent:
                pass#cConfig().error("%s (%d),%s" % (pass#cConfig().getlanguage(30205), e.code , self.__sUrl))
                return ''
        
        if (self.__bRemoveNewLines == True):
            sContent = sContent.replace("\n","")
            sContent = sContent.replace("\r\t","")

        if (self.__bRemoveBreakLines == True):
            sContent = sContent.replace("&nbsp;","")

        return sContent

    def getHeaderLocationUrl(self):        
        opened = urllib.urlopen(self.__sUrl)
        return opened.geturl()

#******************************************************************************
#from https://github.com/eliellis/mpart.py

def MPencode(fields):
    import mimetypes
    random_boundary = __randy_boundary()
    content_type = "multipart/form-data, boundary=%s" % random_boundary

    form_data = []
    
    if fields:
        for (key, value) in fields.iteritems():
            if not hasattr(value, 'read'):
                itemstr = '--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (random_boundary, key, value)
                form_data.append(itemstr)
            elif hasattr(value, 'read'):
                with value:
                    file_mimetype = mimetypes.guess_type(value.name)[0] if mimetypes.guess_type(value.name)[0] else 'application/octet-stream'
                    itemstr = '--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\nContent-Type: %s\r\n\r\n%s\r\n' % (random_boundary, key, value.name, file_mimetype, value.read())
                form_data.append(itemstr)
            else:
                raise Exception(value, 'Field is neither a file handle or any other decodable type.')
    else:
        pass

    form_data.append('--%s--\r\n' % random_boundary)

    return content_type, ''.join(form_data)

def __randy_boundary(length=10,reshuffle=False):
    import random,string
    
    character_string = string.letters+string.digits
    boundary_string = []
    for i in range(0,length):
        rand_index = random.randint(0,len(character_string) - 1)
        boundary_string.append(character_string[rand_index])
    if reshuffle:
        random.shuffle(boundary_string)
    else:
        pass
    return ''.join(boundary_string)

class cPacker():
    def detect(self, source):
        """Detects whether `source` is P.A.C.K.E.R. coded."""
        return source.replace(' ', '').startswith('eval(function(p,a,c,k,e,')

    def unpack(self, source):
        """Unpacks P.A.C.K.E.R. packed js code."""
        payload, symtab, radix, count = self._filterargs(source)

        if count != len(symtab):
            raise UnpackingError('Malformed p.a.c.k.e.r. symtab.')
        
        try:
            unbase = Unbaser(radix)
        except TypeError:
            raise UnpackingError('Unknown p.a.c.k.e.r. encoding.')

        def lookup(match):
            """Look up symbols in the synthetic symtab."""
            word  = match.group(0)
            return symtab[unbase(word)] or word

        source = re.sub(r'\b\w+\b', lookup, payload)
        return self._replacestrings(source)

    def _cleanstr(self, str):
        str = str.strip()
        if str.find("function") == 0:
            pattern = (r"=\"([^\"]+).*}\s*\((\d+)\)")
            args = re.search(pattern, str, re.DOTALL)
            if args:
                a = args.groups()
                def openload_re(match):
                    c = match.group(0)
                    b = ord(c) + int(a[1])
                    return chr(b if (90 if c <= "Z" else 122) >= b else b - 26)

                str = re.sub(r"[a-zA-Z]", openload_re, a[0]);
                str = urllib2.unquote(str)

        elif str.find("decodeURIComponent") == 0:
            str = re.sub(r"(^decodeURIComponent\s*\(\s*('|\"))|(('|\")\s*\)$)", "", str);
            str = urllib2.unquote(str)
        elif str.find("\"") == 0:
            str = re.sub(r"(^\")|(\"$)|(\".*?\")", "", str);
        elif str.find("'") == 0:
            str = re.sub(r"(^')|('$)|('.*?')", "", str);

        return str

    def _filterargs(self, source):
        """Juice from a source file the four args needed by decoder."""
        
        source = source.replace(',[],',',0,')

        juicer = (r"}\s*\(\s*(.*?)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*\((.*?)\).split\((.*?)\)")
        args = re.search(juicer, source, re.DOTALL)
        if args:
            a = args.groups()
            try:
                return self._cleanstr(a[0]), self._cleanstr(a[3]).split(self._cleanstr(a[4])), int(a[1]), int(a[2])
            except ValueError:
                raise UnpackingError('Corrupted p.a.c.k.e.r. data.')

        juicer = (r"}\('(.*)', *(\d+), *(\d+), *'(.*)'\.split\('(.*?)'\)")
        args = re.search(juicer, source, re.DOTALL)
        if args:
            a = args.groups()
            try:
                return a[0], a[3].split(a[4]), int(a[1]), int(a[2])
            except ValueError:
                raise UnpackingError('Corrupted p.a.c.k.e.r. data.')

        # could not find a satisfying regex
        raise UnpackingError('Could not make sense of p.a.c.k.e.r data (unexpected code structure)')



    def _replacestrings(self, source):
        """Strip string lookup table (list) and replace values in source."""
        match = re.search(r'var *(_\w+)\=\["(.*?)"\];', source, re.DOTALL)

        if match:
            varname, strings = match.groups()
            startpoint = len(match.group(0))
            lookup = strings.split('","')
            variable = '%s[%%d]' % varname
            for index, value in enumerate(lookup):
                source = source.replace(variable % index, '"%s"' % value)
            return source[startpoint:]
        return source
        
def UnpackingError(Exception):
    #Badly packed source or general error.#
    #xbmc.log(str(Exception))
    print Exception
    pass


class Unbaser(object):
    """Functor for a given base. Will efficiently convert
    strings to natural numbers."""
    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: (' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
             '[\]^_`abcdefghijklmnopqrstuvwxyz{|}~')
    }

    def __init__(self, base):
        self.base = base
        
        #Error not possible, use 36 by defaut
        if base == 0 :
            base = 36
        
        # If base can be handled by int() builtin, let it do it for us
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
        else:
            if base < 62:
                self.ALPHABET[base] = self.ALPHABET[62][0:base]
            elif 62 < base < 95:
                self.ALPHABET[base] = self.ALPHABET[95][0:base]
            # Build conversion dictionary cache
            try:
                self.dictionary = dict((cipher, index) for index, cipher in enumerate(self.ALPHABET[base]))
            except KeyError:
                raise TypeError('Unsupported base encoding.')

            self.unbase = self._dictunbaser

    def __call__(self, string):
        return self.unbase(string)

    def _dictunbaser(self, string):
        """Decodes a  value to an integer."""
        ret = 0
        
        for index, cipher in enumerate(string[::-1]):
            ret += (self.base ** index) * self.dictionary[cipher]
        return ret



class JJDecoder(object):

	def __init__(self, jj_encoded_data):
		self.encoded_str = jj_encoded_data

		
	def clean(self):
		return re.sub('^\s+|\s+$', '', self.encoded_str)

		
	def checkPalindrome(self, Str):
		startpos = -1
		endpos = -1
		gv, gvl = -1, -1

		index = Str.find('"\'\\"+\'+",')

		if index == 0:
			startpos = Str.find('$$+"\\""+') + 8
			endpos = Str.find('"\\"")())()')
			gv = Str[Str.find('"\'\\"+\'+",')+9:Str.find('=~[]')]
			gvl = len(gv)
		else:
			gv = Str[0:Str.find('=')]
			gvl = len(gv)
			startpos = Str.find('"\\""+') + 5
			endpos = Str.find('"\\"")())()')

		return (startpos, endpos, gv, gvl)

		
	def decode(self):
		
		self.encoded_str = self.clean()
		startpos, endpos, gv, gvl = self.checkPalindrome(self.encoded_str)

		if startpos == endpos:
			raise Exception('No data!')

		data = self.encoded_str[startpos:endpos]

		b = ['___+', '__$+', '_$_+', '_$$+', '$__+', '$_$+', '$$_+', '$$$+', '$___+', '$__$+', '$_$_+', '$_$$+', '$$__+', '$$_$+', '$$$_+', '$$$$+']

		str_l = '(![]+"")[' + gv + '._$_]+'
		str_o 	= gv + '._$+'
		str_t = gv + '.__+'
		str_u = gv + '._+'
		
		str_hex = gv + '.'

		str_s = '"'
		gvsig = gv + '.'

		str_quote = '\\\\\\"'
		str_slash = '\\\\\\\\'

		str_lower = '\\\\"+'
		str_upper = '\\\\"+' + gv + '._+'

		str_end	= '"+'

		out = ''
		while data != '':
			# l o t u
			if data.find(str_l) == 0:
				data = data[len(str_l):]
				out += 'l'
				continue
			elif data.find(str_o) == 0:
				data = data[len(str_o):]
				out += 'o'
				continue
			elif data.find(str_t) == 0:
				data = data[len(str_t):]
				out += 't'
				continue
			elif data.find(str_u) == 0:
				data = data[len(str_u):]
				out += 'u'
				continue

			# 0123456789abcdef
			if data.find(str_hex) == 0:
				data = data[len(str_hex):]
				
				for i in range(len(b)):
					if data.find(b[i]) == 0:
						data = data[len(b[i]):]
						out += '%x' % i
						break
				continue

			# start of s block
			if data.find(str_s) == 0:
				data = data[len(str_s):]

				# check if "R
				if data.find(str_upper) == 0: # r4 n >= 128
					data = data[len(str_upper):] # skip sig
					ch_str = ''
					for i in range(2): # shouldn't be more than 2 hex chars
						# gv + "."+b[ c ]
						if data.find(gvsig) == 0:
							data = data[len(gvsig):]
							for k in range(len(b)): # for every entry in b
								if data.find(b[k]) == 0:
									data = data[len(b[k]):]
									ch_str = '%x' % k
									break
						else:
							break

					out += chr(int(ch_str, 16))
					continue

				elif data.find(str_lower) == 0: # r3 check if "R // n < 128
					data = data[len(str_lower):] # skip sig
					
					ch_str = ''
					ch_lotux = ''
					temp = ''
					b_checkR1 = 0
					for j in range(3): # shouldn't be more than 3 octal chars
						if j > 1: # lotu check
							if data.find(str_l) == 0:
								data = data[len(str_l):]
								ch_lotux = 'l'
								break
							elif data.find(str_o) == 0:
								data = data[len(str_o):]
								ch_lotux = 'o'
								break
							elif data.find(str_t) == 0:
								data = data[len(str_t):]
								ch_lotux = 't'
								break
							elif data.find(str_u) == 0:
								data = data[len(str_u):]
								ch_lotux = 'u'
								break

						# gv + "."+b[ c ]
						if data.find(gvsig) == 0:
							temp = data[len(gvsig):]
							for k in range(8): # for every entry in b octal
								if temp.find(b[k]) == 0:
									if int(ch_str + str(k), 8) > 128:
										b_checkR1 = 1
										break

									ch_str += str(k)
									data = data[len(gvsig):] # skip gvsig
									data = data[len(b[k]):]
									break

							if b_checkR1 == 1:
								if data.find(str_hex) == 0: # 0123456789abcdef
									data = data[len(str_hex):]
									# check every element of hex decode string for a match
									for i in range(len(b)):
										if data.find(b[i]) == 0:
											data = data[len(b[i]):]
											ch_lotux = '%x' % i
											break
									break
						else:
							break

					out += chr(int(ch_str,8)) + ch_lotux
					continue

				else: # "S ----> "SR or "S+
					# if there is, loop s until R 0r +
					# if there is no matching s block, throw error
					
					match = 0;
					n = None

					# searching for matching pure s block
					while True:
						n = ord(data[0])
						if data.find(str_quote) == 0:
							data = data[len(str_quote):]
							out += '"'
							match += 1
							continue
						elif data.find(str_slash) == 0:
							data = data[len(str_slash):]
							out += '\\'
							match += 1
							continue
						elif data.find(str_end) == 0: # reached end off S block ? +
							if match == 0:
								raise '+ no match S block: ' + data
							data = data[len(str_end):]
							break # step out of the while loop
						elif data.find(str_upper) == 0: # r4 reached end off S block ? - check if "R n >= 128
							if match == 0:
								raise 'no match S block n>128: ' + data
							data = data[len(str_upper):] # skip sig
							
							ch_str = ''
							ch_lotux = ''

							for j in range(10): # shouldn't be more than 10 hex chars
								if j > 1: # lotu check
									if data.find(str_l) == 0:
										data = data[len(str_l):]
										ch_lotux = 'l'
										break
									elif data.find(str_o) == 0:
										data = data[len(str_o):]
										ch_lotux = 'o'
										break
									elif data.find(str_t) == 0:
										data = data[len(str_t):]
										ch_lotux = 't'
										break
									elif data.find(str_u) == 0:
										data = data[len(str_u):]
										ch_lotux = 'u'
										break

								# gv + "."+b[ c ]
								if data.find(gvsig) == 0:
									data = data[len(gvsig):] # skip gvsig
									for k in range(len(b)): # for every entry in b
										if data.find(b[k]) == 0:
											data = data[len(b[k]):]
											ch_str += '%x' % k
											break
								else:
									break # done
							out += chr(int(ch_str, 16))
							break # step out of the while loop
						elif data.find(str_lower) == 0: # r3 check if "R // n < 128
							if match == 0:
								raise 'no match S block n<128: ' + data

							data = data[len(str_lower):] # skip sig

							ch_str = ''
							ch_lotux = ''
							temp = ''
							b_checkR1 = 0

							for j in range(3): # shouldn't be more than 3 octal chars
								if j > 1: # lotu check
									if data.find(str_l) == 0:
										data = data[len(str_l):]
										ch_lotux = 'l'
										break
									elif data.find(str_o) == 0:
										data = data[len(str_o):]
										ch_lotux = 'o'
										break
									elif data.find(str_t) == 0:
										data = data[len(str_t):]
										ch_lotux = 't'
										break
									elif data.find(str_u) == 0:
										data = data[len(str_u):]
										ch_lotux = 'u'
										break

								# gv + "."+b[ c ]
								if data.find(gvsig) == 0:
									temp = data[len(gvsig):]
									for k in range(8): # for every entry in b octal
										if temp.find(b[k]) == 0:
											if int(ch_str + str(k), 8) > 128:
												b_checkR1 = 1
												break

											ch_str += str(k)
											data = data[len(gvsig):] # skip gvsig
											data = data[len(b[k]):]
											break

									if b_checkR1 == 1:
										if data.find(str_hex) == 0: # 0123456789abcdef
											data = data[len(str_hex):]
											# check every element of hex decode string for a match
											for i in range(len(b)):
												if data.find(b[i]) == 0:
													data = data[len(b[i]):]
													ch_lotux = '%x' % i
													break
								else:
									break
							out += chr(int(ch_str, 8)) + ch_lotux
							break # step out of the while loop
						elif (0x21 <= n and n <= 0x2f) or (0x3A <= n and n <= 0x40) or ( 0x5b <= n and n <= 0x60 ) or ( 0x7b <= n and n <= 0x7f ):
							out += data[0]
							data = data[1:]
							match += 1
					continue
			print 'No match : ' + data
			break
		return out

class AADecoder(object):
    def __init__(self, aa_encoded_data):
        self.encoded_str = aa_encoded_data.replace('/*´∇｀*/','')

        self.b = ["(c^_^o)", "(ﾟΘﾟ)", "((o^_^o) - (ﾟΘﾟ))", "(o^_^o)",
                  "(ﾟｰﾟ)", "((ﾟｰﾟ) + (ﾟΘﾟ))", "((o^_^o) +(o^_^o))", "((ﾟｰﾟ) + (o^_^o))",
                  "((ﾟｰﾟ) + (ﾟｰﾟ))", "((ﾟｰﾟ) + (ﾟｰﾟ) + (ﾟΘﾟ))", "(ﾟДﾟ) .ﾟωﾟﾉ", "(ﾟДﾟ) .ﾟΘﾟﾉ",
                  "(ﾟДﾟ) ['c']", "(ﾟДﾟ) .ﾟｰﾟﾉ", "(ﾟДﾟ) .ﾟДﾟﾉ", "(ﾟДﾟ) [ﾟΘﾟ]"]

    def is_aaencoded(self):
        idx = self.encoded_str.find("ﾟωﾟﾉ= /｀ｍ´）ﾉ ~┻━┻   //*´∇｀*/ ['_']; o=(ﾟｰﾟ)  =_=3; c=(ﾟΘﾟ) =(ﾟｰﾟ)-(ﾟｰﾟ); ")
        if idx == -1:
            return False

        if self.encoded_str.find("(ﾟДﾟ)[ﾟoﾟ]) (ﾟΘﾟ)) ('_');", idx) == -1:
            return False

        return True

    def base_repr(self, number, base=2, padding=0):
        digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        if base > len(digits):
            base = len(digits)

        num = abs(number)
        res = []
        while num:
            res.append(digits[num % base])
            num //= base
        if padding:
            res.append('0' * padding)
        if number < 0:
            res.append('-')
        return ''.join(reversed(res or '0'))

    def decode_char(self, enc_char, radix):
        end_char = "+ "
        str_char = ""
        while enc_char != '':
            found = False
            #for i in range(len(self.b)):
            #    if enc_char.find(self.b[i]) == 0:
            #        str_char += self.base_repr(i, radix)
            #        enc_char = enc_char[len(self.b[i]):]
            #        found = True
            #        break

            if not found:
                for i in range(len(self.b)):             
                    enc_char=enc_char.replace(self.b[i], str(i))
                
                startpos=0
                findClose=True
                balance=1
                result=[]
                if enc_char.startswith('('):
                    l=0
                    
                    for t in enc_char[1:]:
                        l+=1
                        if findClose and t==')':
                            balance-=1;
                            if balance==0:
                                result+=[enc_char[startpos:l+1]]
                                findClose=False
                                continue
                        elif not findClose and t=='(':
                            startpos=l
                            findClose=True
                            balance=1
                            continue
                        elif t=='(':
                            balance+=1
                 

                if result is None or len(result)==0:
                    return ""
                else:
                    
                    for r in result:
                        value = self.decode_digit(r, radix)
                        if value == "":
                            return ""
                        else:
                            str_char += value
                            
                    return str_char

            enc_char = enc_char[len(end_char):]

        return str_char

        
              
    def decode_digit(self, enc_int, radix):

        #enc_int=enc_int.replace('(ﾟΘﾟ)','1').replace('(ﾟｰﾟ)','4').replace('(c^_^o)','0').replace('(o^_^o)','3')  

        rr = '(\(.+?\)\))\+'
        rerr=enc_int.split('))+')
        v = ''
        
        #new mode
        if (True):

            for c in rerr:
                
                if len(c)>0:
                    if c.strip().endswith('+'):
                        c=c.strip()[:-1]

                    startbrackets=len(c)-len(c.replace('(',''))
                    endbrackets=len(c)-len(c.replace(')',''))
                    
                    if startbrackets>endbrackets:
                        c+=')'*startbrackets-endbrackets
                    
                    #fh = open('c:\\test.txt', "w")
                    #fh.write(c)
                    #fh.close()
                    
                    c = c.replace('!+[]','1')
                    c = c.replace('-~','1+')
                    c = c.replace('[]','0')
                    
                    v+=str(eval(c))
                    
            return v
         
        # mode 0=+, 1=-
        mode = 0
        value = 0

        while enc_int != '':
            found = False
            for i in range(len(self.b)):
                if enc_int.find(self.b[i]) == 0:
                    if mode == 0:
                        value += i
                    else:
                        value -= i
                    enc_int = enc_int[len(self.b[i]):]
                    found = True
                    break

            if not found:
                return ""

            enc_int = re.sub('^\s+|\s+$', '', enc_int)
            if enc_int.find("+") == 0:
                mode = 0
            else:
                mode = 1

            enc_int = enc_int[1:]
            enc_int = re.sub('^\s+|\s+$', '', enc_int)

        return self.base_repr(value, radix)

    def decode(self):

        self.encoded_str = re.sub('^\s+|\s+$', '', self.encoded_str)

        # get data
        pattern = (r"\(ﾟДﾟ\)\[ﾟoﾟ\]\+ (.+?)\(ﾟДﾟ\)\[ﾟoﾟ\]\)")
        result = re.search(pattern, self.encoded_str, re.DOTALL)
        if result is None:
            print "AADecoder: data not found"
            return False

        data = result.group(1)

        # hex decode string
        begin_char = "(ﾟДﾟ)[ﾟεﾟ]+"
        alt_char = "(oﾟｰﾟo)+ "

        out = ''

        while data != '':
            # Check new char
            if data.find(begin_char) != 0:
                print "AADecoder: data not found"
                return False

            data = data[len(begin_char):]

            # Find encoded char
            enc_char = ""
            if data.find(begin_char) == -1:
                enc_char = data
                data = ""
            else:
                enc_char = data[:data.find(begin_char)]
                data = data[len(enc_char):]

            
            radix = 8
            # Detect radix 16 for utf8 char
            if enc_char.find(alt_char) == 0:
                enc_char = enc_char[len(alt_char):]
                radix = 16

            str_char = self.decode_char(enc_char, radix)
            
            if str_char == "":
                print "no match :  "
                print  data + "\nout = " + out + "\n"
                return False
            
            out += chr(int(str_char, radix))

        if out == "":
            print "no match : " + data
            return False

        return out

def ASCIIDecode(string):
    
    i = 0
    l = len(string)
    ret = ''
    while i < l:
        c =string[i]
        if string[i:(i+2)] == '\\x':
            c = chr(int(string[(i+2):(i+4)],16))
            i+=3
        if string[i:(i+2)] == '\\u':
            cc = int(string[(i+2):(i+6)],16)
            if cc > 256:
                #ok c'est de l'unicode, pas du ascii
                return ''
            c = chr(cc)
            i+=5     
        ret = ret + c
        i = i + 1

    return ret

def SubHexa(g):
    return g.group(1) + Hexa(g.group(2))
    
def Hexa(string):
    return str(int(string, 0))

def parseInt(sin):
    return int(''.join([c for c in re.split(r'[,.]',str(sin))[0] if c.isdigit()])) if re.match(r'\d+', str(sin), re.M) and not callable(sin) else None

def CheckCpacker(str):

    sPattern = '(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
    aResult = re.findall(sPattern,str)
    if (aResult):
        str2 = aResult[0]
        if not str2.endswith(';'):
            str2 = str2 + ';'
        try:
            str = cPacker().unpack(str2)
            print('Cpacker encryption')
        except:
            pass

    return str
    
def CheckJJDecoder(str):

    sPattern = '([a-z]=.+?\(\)\)\(\);)'
    aResult = re.findall(sPattern,str)
    if (aResult):
        print('JJ encryption')
        return JJDecoder(aResult[0]).decode()
        
    return str
    
def CheckAADecoder(str):
    aResult = re.search('([>;]\s*)(ﾟωﾟ.+?\(\'_\'\);)', str,re.DOTALL | re.UNICODE)
    if (aResult):
        #print('AA encryption')
        tmp = aResult.group(1) + AADecoder(aResult.group(2)).decode()
        return str[:aResult.start()] + tmp + str[aResult.end():]
        
    return str
    
def CleanCode(code,Coded_url):
    #extract complete code
    r = re.search(r'type="text\/javascript">(.+?)<\/script>', code,re.DOTALL)
    if r:
        code = r.group(1)

    #1 er decodage
    code = ASCIIDecode(code)
    
    #fh = open('c:\\html2.txt', "w")
    #fh.write(code)
    #fh.close()

    #extract first part
    P3 = "^(.+?)}\);\s*\$\(\"#videooverlay"
    r = re.search(P3, code,re.DOTALL)
    if r:
        code = r.group(1)
    else:
        pass#cConfig().log('er1')
        return False
        
    #hack a virer dans le futur
    code = code.replace('!![]','true')
    P8 = '\$\(document\).+?\(function\(\){'
    code= re.sub(P8,'\n',code)
    P4 = 'if\(!_[0-9a-z_\[\(\'\)\]]+,document[^;]+\)\){'
    code = re.sub(P4,'if (false) {',code)
    P4 = 'if\(+\'toString\'[^;]+document[^;]+\){'
    code = re.sub(P4,'if (false) {',code)

    #hexa convertion
    code = re.sub('([^_])(0x[0-9a-f]+)',SubHexa,code)
     
    #Saut de ligne
    #code = code.replace(';',';\n')
    code = code.replace('case','\ncase')
    code = code.replace('}','\n}\n')
    code = code.replace('{','{\n')

    #tab
    code = code.replace('\t','')

    #hack
    code = code.replace('!![]','true')

    return code
    
#************************************************************
#Fonctions non utilisées, juste la pour memoire
#************************************************************

def GetOpenloadUrl(url,referer):
    if 'openload.co/stream' in url:
    
        headers = {'User-Agent': FF_USER_AGENT,
                   #'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   #'Accept-Language':'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                   #'Accept-Encoding':'gzip, deflate, br',
                   #'Host':'openload.co',
                   'Referer':referer
        }

        req = urllib2.Request(url,None,headers)
        res = urllib2.urlopen(req)
        #xbmc.log(res.read())
        finalurl = res.geturl()

        
        pass#xbmc.log('Url decodee : ' + finalurl)
        
        #autres infos
        #xbmc.log(str(res.info()))
        #xbmc.log(res.info()['Content-Length'])
        
        if 'KDA_8nZ2av4/x.mp4' in finalurl:
            pass#xbmc.log('pigeon url : ' + url)
            finalurl = ''
        if 'Content-Length' in res.info():
            if res.info()['Content-Length'] == '33410733':
                pass#xbmc.log('pigeon url : ' + url)
                finalurl = ''
        if url == finalurl:
            pass#xbmc.log('Bloquage')
            finalurl = ''        

        return finalurl
    return url
    
#Code updated with code from https://gitlab.com/iptvplayer-for-e2 
def decodek(k):
    y = ord(k[0]);
    e = y - 0x37
    d = max(2, e)
    e = min(d, len(k) - 0x24 - 2)
    t = k[e:e + 0x24]
    h = 0
    g = []
    while h < len(t):
        f = t[h:h+3]
        g.append(int(f, 0x8))
        h += 3
    v = k[0:e] + k[e+0x24:]
    p = []
    i = 0
    h = 0
    while h < len(v):
        B = v[h:h + 2]
        C = v[h:h + 3]
        f = int(B, 0x10)
        h += 0x2
 
        if (i % 3) == 0:
            f = int(C, 8)
            h += 1
        elif i % 2 == 0 and i != 0 and ord(v[i-1]) < 0x3c:
            f = int(C, 0xa)
            h += 1

        A = g[i % 0xc]
        f = f ^ 0xd5;
        f = f ^ A;
        p.append(chr(f))
        i += 1

    return "".join(p)
 
 #****************************************************************************************
 #
 #    JS Interpreter, full code https://github.com/TmpName/TinyJSParser
 #
 #*****************************************************************************************
 
 


import types
from types import NoneType
import time

import sys

REG_NAME = '[\w]+'
REG_OP = '[\/\*\-\+\{\}<>\|\&=~^%!]+' #not space here, and no bracket
DEBUG = False # Never enable it in kodi, too big size log
MAX_RECURSION = 50
ALPHA = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'

#---------------------------------------------------------------------------------


def RemoveGuil(string):
    if not (isinstance(string, types.StringTypes)):
        return string
    string = string.strip()
    if string.startswith('"') and string.endswith('"'):
        return string[1:-1]
    if string.startswith("'") and string.endswith("'"):
        return string[1:-1]            
    return string


def ASCIIDecode(string):
    i = 0
    l = len(string)
    ret = ''
    while i < l:
        c =string[i]
        if string[i:(i+2)] == '\\x':
            c = chr(int(string[(i+2):(i+4)],16))
            i+=3
        if string[i:(i+2)] == '\\u':
            c = chr(int(string[(i+2):(i+6)],16))
            i+=5     
        ret = ret + c
        i += 1

    return ret

def IsUnicode(s):
    if isinstance(s, unicode):
        return True
    return False
   
def out(string):
    if DEBUG:
        print str(string.decode('latin-1').encode('ascii','replace'))
        
def Ustr(string):
    if isinstance(string, unicode):
        return str(string.encode('ascii','replace'))
    return str(string)
    
def GetNextchar(string, pos):
    if len(string) <= (pos + 1):
        return ''
    return string[pos+1]
    
def GetNextUsefullchar(string):
    j = 0
    try:
        while (string[j].isspace()):
            j += 1
    except:
        return '',0       
    return string[j],j

    
def GetPrevchar(string, pos):
    if (pos - 1) < 0:
        return ''
    return string[pos-1]
        
def CheckType(value):
    if (isinstance(value, types.StringTypes)):
        return 'String'
    if isinstance(value, ( bool ) ):
        return 'Bool'
    if isinstance(value, ( int, long, float ) ):
        return 'Numeric'
    if type(value) in [list,tuple, dict]:
        return 'Array'
    if (isinstance(value, (NoneType))):
        return 'Undefined'
    if isinstance(value, fonction):
        return 'Fonction'        
    return 'Unknow'

#Fonction to return only one parameter from a string with correct closed [] () "" and ''      
def GetItemAlone(string,separator = ' '):

    l = len(string) - 1
    ret = ''

    i = -1
    p = 0 #parenthese
    a = 0 #accolade
    b = 0 #bracket
    c1 = 0 #chain with "
    c2 = 0 #chain with '
    n = False
    last_char = ''

    s = False
    
    while (i < l):
        i += 1
        ch = string[i]
        ret = ret + ch
        n = False
        
        #Return if the is complete and before the char wanted but not if it's the first one
        if (ch in separator)  and not p and not a and not b and  not c1 and not c2 and not n and (i>0):
            return ret[:-1]
        
        #Skip empty space
        if (ch.isspace()):
            continue

        if ch == '"' and not GetPrevchar(string,i) == '\\' and not c2:
            c1 = 1 - c1
        if ch == "'" and not GetPrevchar(string,i) == '\\' and not c1:
            c2 = 1 - c2

        if not c1 and not c2:
            if ch == '(':
                p += 1
            if ch == ')':
                p -= 1
            if ch == '{':
                a += 1
            if ch == '}':
                a -= 1
            if ch == '[':
                b += 1
            if ch == ']':
                b -= 1

            if ch == '.' and not ((last_char in '0123456789') or (string[i+1] in '0123456789')):
                n = True

        #return if the chain is complete but with the char wanted
        if (ch in separator) and not p and not a and not b and  not c1 and not c2 and not n and (i>0):
            return ret
            
        last_char = ch   

    return ret
    
def MySplit(string,char,NoEmpty = False):
    r = []
    l = len(string)
    i = 0
    chain = 0
    p = 0
    e = ""
    
    if not l:
        if (NoEmpty):
            return []
            
    while (l > i):
        c = string[i]
        if c == '"':
            chain = 1-chain
        if c == '(':
            p += 1
        if c == ')':
            p -= 1           
            
        if (c == char) and not chain and not p:
            r.append(e.strip())
            e = ''
        else:    
            e += c
            
        i += 1

    r.append(e.strip())
    return r
    
def GetConstructor(value):
    if isinstance(value, ( int, long ) ):
        r = fonction('Number','','\n    [native code]\n',True)
        return r
    elif isinstance(value, fonction):
        r = fonction('Function','','\n    [native code]\n',True)
        return r
    elif (isinstance(value, types.StringTypes)):
        r = fonction('String','','\n    [native code]\n',True)
        return r
    return ''

class JSBuffer(object):
    PRIORITY = {'+':3 , '-':3 , '*':4 , '/':4 , '>':1 , '<':1 , '&':2 , '|':2}

    def __init__(self):
        self.type = None
        self.buffer = ''
        self.__op = ''
        self.__value = None
        
        #buffers
        self.buf=[]
        self.opBuf = []
        
    def SetOp(self,op):
        if (op == '&') and  (self.__op == '&'):
            return
        if (op == '|') and  (self.__op == '|'):
            return
        else:
            self.__op = self.__op + op
            
    def CheckString(self):
        if len(self.buf) >= len(self.opBuf):
            return True
        return False
        
    #Need 3 values for priority   
    def AddValue(self,value):
        out('ADD ' + Ustr(value) + ' ' + Ustr(type(value)) + ' a ' + Ustr(self.buf))
        
        if not self.type:
            self.type = CheckType(value)
            self.Push(value,self.__op)
            return       
         
        if not self.__op:
            out( 'op ' + str(self.opBuf) + ' - buff ' +str(self.buf))
            raise Exception("Missing operator")
            
        self.Push(value,self.__op)
        self.__op = ''
    
    def GetPrevious(self):
        ret = None
        if len(self.buf) > 0:
            ret = self.buf[-1]
            del self.buf[-1]
            self.__op = self.opBuf[-1]
            del self.opBuf[-1]
        if not len(self.buf):
            self.type = None
            
        return ret
        
    def Compute(self):
    
        #check type
        if len(self.buf) > 1:
            if not (self.type == CheckType(self.buf[len(self.buf) -1])):
                #Type different mais juste operation logique
                if self.opBuf[1] == '==':
                    self.type = 'Logic'
                #Type different mais JS convertis en string
                else:
                    out('string convertion')
                    
                    if not CheckType(self.buf[0]) == 'String':
                        self.buf[0]=self.SpecialStr(self.buf[0])
                    if len(self.buf) > 1:
                        if not CheckType(self.buf[1]) == 'String':
                            self.buf[1]=self.SpecialStr(self.buf[1])
                    self.type = 'String'

        #Work for operateur + | !
        if self.type == 'String':
            if '!' in self.opBuf[0]:
                self.buf[0] = not self.buf[0]
                self.opBuf[0] = self.opBuf[0].replace('!','')
            if len(self.buf) > 1:
                if self.opBuf[1] == '!':
                    self.buf[1] = not self.buf[1]
                    self.opBuf[1] = self.opBuf[1].replace('!','')
                if self.opBuf[1] == '+':
                    self.buf[0] = self.buf[0] + self.buf[1]
                if self.opBuf[1] == '|':
                    if not self.buf[0]:
                        self.buf[0] = self.buf[1]
                if '==' in self.opBuf[1]:
                    self.buf[0] = (self.buf[1] == self.buf[0])
                    self.type == 'Logic'
                if '!=' in self.opBuf[1]:
                    self.buf[0] = (self.buf[1] != self.buf[0])
                    self.type == 'Logic'
                    
                #decale
                del self.opBuf[-1]
                del self.buf[-1]
                                       
        #work for all operator      
        elif self.type == 'Numeric':
            if len(self.buf) > 1:
                self.buf[0] = self.opBuf[0] + str(self.buf[0]) + self.opBuf[1] + str(self.buf[1])
                self.opBuf[0] = ''
                #decale
                del self.opBuf[-1]
                del self.buf[-1]
            else:
                self.buf[0] = self.opBuf[0] + str(self.buf[0])
                self.opBuf[0] = ''

        #work for bool     
        elif self.type == 'Bool':
            if len(self.buf) > 1:
                self.buf[0] = self.opBuf[0] + str(self.buf[0]) + self.opBuf[1] + str(self.buf[1])
                self.opBuf[0] = ''
                #decale
                del self.opBuf[-1]
                del self.buf[-1]
            else:
                self.buf[0] = self.opBuf[0] + str(self.buf[0])
                self.opBuf[0] = ''
                
        # work for
        elif self.type == 'Logic':
            if not self.buf[0] == self.buf[1]:
                self.buf[0] = False
            else:
                self.buf[0] = True
            #decale
            del self.opBuf[-1]
            del self.buf[-1]
            
        elif len(self.buf) > 1:
            print self.type
            print self.buf
            print self.opBuf
            raise Exception("Can't compute")
    
    #on decale tout
    def Push(self,value,op):
        
        if len(self.buf) > 1:
            self.Compute()

        self.buf.append(value)
        self.opBuf.append(op)
        return

    def SpecialStr(self,value):
        if CheckType(value) == 'Numeric':
            return str(value)
        if value == None:
            return 'Undefined'
        if value == True:
            return 'true'
        if value == False:
            return 'false'
        if type(value) in [list]:
            convert_first_to_generator = (str(w) for w in value)
            return ','.join(convert_first_to_generator)
        if type(value) in [dict]:
            return '[object Object]'
        if CheckType(value) == 'Fonction':
            return value.ToStr()
        
        return str(value)
    
    #ok all finished, force compute
    def GetBuffer(self):

        #Force compute
        self.Compute()
        while len(self.buf) > 1:
            self.Compute()
          
        if self.type == 'Logic':
            return self.buf[0]
    
        if self.type == 'Numeric':
            return self.SafeEval(self.buf[0])
            
        if self.type == 'Bool':
            if self.SafeEval(self.buf[0].replace('True','1').replace('False','0')):
                return True
            else:
                return False
        
        if self.type == None:
            return ''
        
        return self.buf[0]
        
    #WARNING : Take care if you edit this function, eval is realy unsafe.
    #better to use ast.literal_eval() but not implemented before python 3
    def SafeEval(self,str):
        if not str:
            raise Exception ('Nothing to eval')
        f = re.search('[^0-9+-.\(\)<>=&%!*\^\/]',str)
        if f:
            raise Exception ('Wrong parameter to Eval : ' + str)
            return 0
        str = str.replace('!','not ')
        #str = str.replace('=','==')
        #print '>>' + str
        return eval(str)
        
        
class fonction(object):
    def __init__(self, name,param, data,c = False):
        self.name = name
        self.code = data
        self.param = param
        self.const = c
        
    def ToStr(self):
        return 'function ' + self.name + '(' + str(self.param)[1:-1] + ') {'+ self.code + '}'
        
class Hack(object):
    def __init__(self,var):
        self.var = var
    def text(self):
        return self.var

class JsParserHelper1(object):
    def __init__(self,tmp_var):
        self.reset()
        self.used = False
        self.Tmp_var = tmp_var
        self.op = None
        
    def reset(self):
        type = None
        self.name = None

        self.t = None
        self.arg = None
        self.rest_code = ''
        #self.op = None
        self.eval = False
        self.property = False
      
    def process(self,JScode):
    
        #IDK why ?
        if self.op:
            return False
        self.reset()
        
        self.at1 = None
        
        #If already started
        if JScode.startswith(self.Tmp_var):
            self.name = self.Tmp_var
        else:
            #si on a rien encore trouve on recherche une variable/fonction
            r = re.search('^(\w[\w]*)',JScode)
            if r and not self.used:
                self.name = r.group(1)
            else:
                return False
            
        self.used = True
            
        #By defaut
        self.t = 'var'
  
        JScode = JScode[(len(self.name)):]
        
        c,p = GetNextUsefullchar(JScode)
        while (c in '.[') and c and not self.at1:
            JScode = JScode[p:]
            if c == '[':
                a = GetItemAlone(JScode,']')
                JScode = JScode[(len(a)):]
                self.at1 = a[1:-1]
                self.eval = True
            if c == '.':
                a = GetItemAlone(JScode[1:],'[(.\/*-+{}<>|=~^%!')
                JScode = JScode[(len(a)+1):]
                self.at1 = a
                self.property = True
                
            c,p = GetNextUsefullchar(JScode)

        if c == '(':
            a = GetItemAlone(JScode,')')
            JScode = JScode[(len(a)):]
            self.arg = a[1:-1]
            self.t = 'fct'
        
        #operation ?
        if not self.t == 'fct':
            m = re.search('^(' + REG_OP + '|\[|$)',JScode, re.UNICODE)
            if m and JScode:
                self.op = m.group(1).strip()
                if self.op == '[':
                    self.op = None
                else:
                    #prb because the only possible case  is ==
                    if len(self.op) > 1 and self.op[0] == '=' and not self.op[1] == '=':
                        self.op = self.op[0]
                              
                    JScode = JScode[(len(self.op)):]
        
        if self.t == 'fct':
            out('Fonction :' + self.name + ' method: ' + str(self.at1) + ' arg: ' + self.arg)
        elif self.t == 'var':
            if self.property:
                self.at1 = '"' + self.at1 + '"'
            out('Variable :' + self.name + ' []= ' + str(self.at1) )
            #Exit if nothing to process
            if (self.name == self.Tmp_var) and not self.at1 and not self.op:
                return False
        if self.op:
            out('operation :' + self.name + ' []= ' + str(self.at1) + ' op: ' + str(self.op) )
            
        self.rest_code = JScode
            
        return True
        
        
class JsParser(object):

    def __init__(self):
        self.Unicode = False
        self.HackVars = []
        self.debug = False
        self.LastEval = ''
        self.SpecialOption = ''
        
        self.Return = False
        self.ReturnValue = None
        
        self.Break = False
        self.continu = False
        
        self.FastEval_vars = []
        self.FastEval_recur = 0
        
        self.option_ForceTest = False
        
                        
    def SetReturn(self,r,v):
        self.Return = True
        self.RecursionReturn = r
        self.ReturnValue = v
        
    def SetOption(self,option):
        if option == 'ForceTest':
            self.option_ForceTest = True
    
    def AddHackVar(self,name, value):
        self.HackVars.append((name,value))
        
    def GetVarHack(self,name):
        return self.GetVar(self.HackVars,name)
        
    def PrintVar(self,vars):
        for i,j in vars:
            print i + ' : ' + str(j)
    
    #Need to take care at chain var with " and '
    def ExtractFirstchain(self,string):

        #print string.encode('ascii','replace')
    
        if not len(string.strip()):
            return '',0
    
        l = len(string)
        string = string + ' ' #To prevent index out of range, hack
        
        i = -1
        p = 0 #parenbthese
        a = 0 #accolade
        b = 0 #bracket
        f = False #fonction ?
        r = False #Regex
        com1 = False
        com2 = False
        prev = '' #previous char
        c1 = 0 #string with "
        c2 = 0 #string with '
        
        stringR = ''
        
        while (l > i):
        
            i += 1
            
            #ignore comment
            if string[i:(i+2)] == '/*':
                com1 = True
            if (com1):
                if string[i:(i+2)] == '*/':
                    com1 = False
                    i += 1
                continue
            if string[i:(i+2)] == '//' and  not (r):
                com2 = True
            if (com2):
                if string[i] == '\n':
                    com2 = False
                else:
                    continue

            ch = string[i]
            
            #if ch == '"' and not GetPrevchar(string,i) == '\\' and not c2:
            if ch == '"' and not c2:
                c1 = 1 - c1
            if ch == "'" and not c1:
                c2 = 1 - c2
            
            #if we are in a chain no more thing to do than waiting for end
            if c1 or c2:
                stringR = stringR + ch
                continue
                
            if ch == '(':
                p += 1
            if ch == ')':
                p -= 1
            if ch == '{':
                a += 1
            if ch == '}':
                a -= 1
            if ch == '[':
                b += 1
            if ch == ']':
                b -= 1
            if (r) and ch == '/':
                r = False
            if ch == '/' and prev == '=':
                r = True

                
            #vire espace inutile
            if ch.isspace() and not c1 and not c2:
                if not( prev in ALPHA and GetNextchar(string,i) in ALPHA ):
                    continue
                
            stringR = stringR + ch
                
            #memorise last char
            if not ch.isspace():
                prev = ch               
                               
            #Dans tout les cas les parenthses doivent etre fermees, ainsi que les crochet
            if not p and not b:
                #Si on rencontre un ; par defaut
                if (ch == ';') and not (f):
                    #Ok, accolade fermees aussi, c'est tout bon
                    if not a:
                        return stringR,i
                    #Accoloade non fermee, c'est une fonction
                    else:
                        f = True
                #si c'est une fonction et l'accolade fermee
                if (f) and not a:
                
                    #quel est le caractere suivant ?
                    j = i + 1
                    while (string[j].isspace()) and(l > j):
                        j += 1
                    #Si parenthese on repart
                    if string[j] == '(':
                        continue
                    
                    # Mal formated string ?
                    # Sometime, coder forget the last ; before the }
                    # Desactived for the moment, because can bug in 'a = {};'
                    if False:
                        j = -2            
                        while (stringR[j].isspace()) or (stringR[j] == '}'):
                            j -= 1
                        if not (stringR[j] == ';'):
                            j += 1
                            stringR = stringR[:j] + ';' + stringR[j:]
                        
                    # if there is a last ; add it
                    if string[i+1] == ';':
                        stringR = stringR + ';'
                        i += 1

                    return stringR,i
        
        #chaine bugguée ?
        if ';' not in string:
            #out('ERROR Extract chain without ";" > ' + string )
            return string.rstrip() + ';', i

        raise Exception("Can't extract chain " + string)

    #Everything Without a "Real" is False   
    def CheckTrueFalse(self,string):
        #out( '> Check True or false : ' + str(string) )

        if isinstance(string, ( bool ) ):
            if string == True:
                return True       
        elif (isinstance(string, types.StringTypes)):
            if not string == '':
                return True
        if isinstance(string, ( int, long , float) ):
            if not (string == 0):
                return True
        if isinstance(string, ( list, tuple) ):
            if not (string == []):
                return True
        return False
        
    #Syntax > aaaaaa.bbbbbb(cccccc) ou bbbb(cccc) ou "aaaa".bb(ccc) ou aa[bb](cc)    
    def FonctionParser(self,vars,allow_recursion,name,function,arg2,JScode):         
      
        arg=arg2.strip()

        out( 'fonction > Name: ' + Ustr(name) + ' arg: ' + Ustr(arg) + ' function: ' + Ustr(function) )

        #hack ?
        if isinstance(name, Hack):
            a = MySplit(arg,',',True)
            
            #In this case function = text but useless ATM

            if a:
            #ecriture
                vv = self.evalJS(a[0],vars,allow_recursion)
                self.AddHackVar(name.var,vv)
                return vv,JScode
            else:
            #lecture
                vv = self.GetVarHack(name.var)
                out('Hack vars (set): ' + vv)
                return vv,JScode

        #Definite function ?
        fe = self.IsFunc(vars,function)
        if not fe:
            try:
                fe = self.IsFunc(vars, '%s["%s"]'%(name,function) )
            except:
                pass

        if fe:
        
            if fe == '$':
                a = MySplit(arg,',',True)
                vv = self.evalJS(a[0],vars,allow_recursion)
                fff = Hack(vv)
                
                return fff,JScode
                
            elif isinstance(fe, types.MethodType):
                #print fe.im_func.__name__ #parseint
                #print fe.im_class.__name__ #Basic
                function = fe.im_func.__name__
                out( "> function (native): " + function + ' arg=' + arg)
                #and continu with native fonction
                
            elif isinstance(fe, fonction):
                out('> fonction definie par code : ' + function)
                n,p,c,ct = fe.name,fe.param,fe.code,fe.const
                a = MySplit(arg,',',True)
                a2 = []
                #out('code de la fonction : ' + c)
                
                if ct:
                    #hack
                    #Make replacement
                    JScode = "%s(%s)%s"%(n,arg,JScode)
                    return '',JScode

                for i in a:
                    vv = self.evalJS(i,vars,allow_recursion)
                    a2.append(RemoveGuil(vv))
                
                List_tmpvar = []
                if (len(p) > 0) and (len(a2)>0):
                    nv = tuple(zip(p, a2))
                    for z,w in nv:
                        self.SetVar(vars,z,w)
                        List_tmpvar.append(z)

                self.Parse(c,vars,allow_recursion)
                
                #And delete tmp var
                for i in List_tmpvar:
                    self.InitVar(vars,i)
                
                if self.Return:
                    self.Return = None
                    
                return self.ReturnValue,JScode
            else:
                raise Exception("Strnage fonction")
                
        #Native fonction
        # http://stackoverflow.com/questions/1091259/how-to-test-if-a-class-attribute-is-an-instance-method
        s = ''
        if type(name) in [list,tuple,dict,types.MethodType,NoneType]:
            s = name
        else:
            if name.startswith('"') or name.startswith("'"):
                s = RemoveGuil(name)
            else:
                if self.IsVar(vars,name):
                    s = self.GetVar(vars,name)
                else:
                    s = name

        for lib in List_Lib:
            if hasattr(lib, function):
                if not function == "eval":
                    arg = MySplit(arg,',')
                    for i in range(len(arg)):
                        arg[i] = self.evalJS(arg[i],vars,allow_recursion)

                #for fastcall
                self.FastEval_vars = vars
                self.FastEval_recur = allow_recursion
                
                cls =  lib(self,s)
                    
                r = getattr(cls, function)(arg)
                
                #set new value if chnaged
                if hasattr(lib, 'Get'):
                    NV = getattr(cls, 'Get')()
                    if not NV == s:
                        self.SetVar(vars,name,NV)
                
                return r,JScode

               
            
        #test, if all is ok, never reached
        if (False):
            #function
            if function=='function':
                pos9 = len(JScode)
                v = self.MemFonction(vars,'',arg,False,JScode)[2]
                JScode = JScode[( pos9):]
                return v,JScode
                
        #constructor
        if function=='Function':
            #pos9 = len(JScode[(len(m.group(0)) + pos3 + 0):])
            NewCode = self.evalJS(arg,vars,allow_recursion)

            v = self.MemFonction(vars,'','',False,'{'+ NewCode + '}')[2]
            #pos3 = pos3 + pos9
            #InterpretedCode.AddValue(v)
            JScode = v + JScode
            return '',JScode

        self.PrintVar(vars)
        raise Exception("Unknow fonction : " + function)
        
    def Fast_Eval(self,strg):
        r = self.evalJS(strg,self.FastEval_vars,self.FastEval_recur)
        return r
        
    def VarParser(self,vars,allow_recursion,variable,op,JScode):

        New_Var = False
      
        out('Variable : ' + str(variable) + '  operator : ' + op )

        # if it's a creation/modification
        if op == '=':
        
            out('creation/modification')

            v1 = GetItemAlone(JScode,',')
            JScode = JScode[(len(v1)):]
            
            v1 = v1.strip()

            self.VarManage(allow_recursion,vars,variable,v1)
            
            #and return it
            r = self.GetVar(vars,variable)
            return r,JScode

            
        if not self.IsVar(vars,variable):
            raise Exception("Can't find var " + str(variable))
        
        r = self.GetVar(vars,variable)
                       
        #Only modification
        if len(op) == 2:
        
            #just put var because not managed here
            if op[0] in '=!':
                return r,op + JScode

            #ok so what is it ?
            out("> var " + variable + "=" + str(r))
            
            #check if it's i++ ou i -- form
            if op == '++':
                self.SetVar(vars,variable,r + 1)
                return r,JScode

            elif op == '--':
                self.SetVar(vars,variable,r-1)
                return r,JScode

            #a+=1 form
            elif op[1] == '=' and op[0] in '+-*/%^':
                n = GetItemAlone(JScode,';,')
                out('A rajouter ' + n)
                r = self.evalJS(variable + op[0] + n ,vars,allow_recursion)
                #self.SetVar(vars,variable,r)
                
                if isinstance(r, ( int, long , float) ):
                    self.VarManage(allow_recursion,vars,variable,str(r))
                if isinstance(r, ( str) ):
                    self.VarManage(allow_recursion,vars,variable,'"'+ r + '"')
                else:
                    self.VarManage(allow_recursion,vars,variable,str(r))
                    
                JScode = JScode[(len(n)):]
                return r,JScode
                
        #just var
        #re-ad op if not used
        JScode = op + JScode
        return r,JScode    
        
    def evalJS(self,JScode,vars,allow_recursion):
    
        if allow_recursion < 0:
            raise Exception('Recursion limit reached')
            
        allow_recursion -= 1

        #plus que la chaine a evaluer
        JScode = JScode.strip()
        
        out( '-------------')
        out( str(allow_recursion) + ' : A evaluer >'+ JScode + '<\n')
            
        #********************************************************
        
        InterpretedCode = JSBuffer()
        
        while (len(JScode)>0):
            c = JScode[0]

            #print 'InterpretedCode > ' + InterpretedCode
            out( 'JScode > ' + JScode.encode('ascii','replace') + '\n')
            
            #parentheses
            if c == "(":
                
                c2 = GetItemAlone(JScode,')')[1:-1]
                pos2 = len(c2) + 2
                JScode = JScode[(pos2):]
                
                v = self.evalJS(c2,vars,allow_recursion)
                self.SetVar(vars,'TEMPORARY_VARS'+str(allow_recursion),v)
                JScode = 'TEMPORARY_VARS'+str(allow_recursion) + JScode
                
            #remove "useless" code
            if JScode.startswith('new '):
                JScode = JScode[4:]
                continue
                
            #in operator            
            if JScode[0:2] == 'in':
                A = InterpretedCode.GetPrevious()
                B = GetItemAlone(JScode[2:],',;&|')
                B2 = self.evalJS(B,vars,allow_recursion)
                
                if type(B2) in [types.MethodType,types.InstanceType]:
                    B2 = str(B2)

                if A in B2:
                    InterpretedCode.AddValue(True)
                else:
                    InterpretedCode.AddValue(False)
                JScode = JScode[(len (B)+2) :]
                continue
                
            #Special value
            m = re.search('^(true|false|null|String)',JScode, re.UNICODE)
            if m:
                v = m.group(1)
                JScode = JScode[len(v):]
                
                if v == 'true':  
                    InterpretedCode.AddValue(True)
                if v == 'false':
                    InterpretedCode.AddValue(False)
                if v == 'null':
                    InterpretedCode.AddValue(None)
                if v == 'String':
                    self.SetVar(vars,'TEMPORARY_VARS'+str(allow_recursion),'')
                    JScode = 'TEMPORARY_VARS'+str(allow_recursion) + JScode
                #if v == 'Array':
                #    InterpretedCode.AddValue([])

                continue
                
                
            #hackVars
            r = re.search('^\$\("#([\w]+)"\)\.text\(\)',JScode)
            if r:
                InterpretedCode.AddValue(self.GetVar(self.HackVars,r.group(1)))
                JScode = JScode[(r.end()):]
                continue
 
            if JScode[0] == '$':
                InterpretedCode.AddValue('$')
                JScode = JScode[1:]
                continue 
                
            #new function delcaration ? Need to be before the fonction/variable parser.
            # var x = function (a, b) {return a * b};
            # function myFunction(a, b) {return a * b};
            if JScode.startswith("function"):
                #m = re.search(r'^(\()* *function(?: ([\w]+))* *\(([^\)]*)\) *{', JScode,re.DOTALL)
                m = re.search(r'^function(?: ([\w]+))* *\(([^\)]*)\) *{', JScode,re.DOTALL)
                if m:
                    name = ''
                    openparenthesis = False
                    if m.group(1):
                        name = m.group(1)
                
                    replac,pos3,v = self.MemFonction(vars,name,m.group(2),openparenthesis,JScode)
                    JScode = replac
                    InterpretedCode.AddValue(v)
                    continue             
                    
            # pointeur vers fonction ?
            if hasattr(Basic, JScode):
                fm = getattr(Basic(self,None), JScode)
                InterpretedCode.AddValue(fm)
                JScode = ''
                continue                
            
            #3 - numeric chain
            r = re.search('(^(?:0x)*[0-9]+)',JScode)
            if r:
                v = JScode[0:r.end()]
                if v.startswith('0x'):
                    v = int(v,0)
                else:
                    v = int(v)
                InterpretedCode.AddValue(v)
                JScode = JScode[(r.end()):]
                continue #for this one continue directly

            #4 - Regex
            r = re.search('^\/.*\/(.*$)',JScode)
            if r:
                reg = r.group(0)
                flag = r.group(1)
                #test if the regex is valid
                if flag:
                    for i in flag:
                        if i not in 'gimuy':
                            reg = None
                            break
                InterpretedCode.AddValue(reg)
                JScode = JScode[(len(r.group(0))):]
                continue #return directly
                
                
            #1 - Array / method
            if c == "[":
                c2 = GetItemAlone(JScode,']')[1:-1]
                pos2 = len(c2) + 2
                #v = self.evalJS(c2,vars,allow_recursion)
                
                #all this part is managed away but not for some rare case.
                A = InterpretedCode.GetPrevious()
                if not A:
                    valueT = MySplit(c2,',')
                    JScode = JScode[(pos2):]
                    valueT = [] #To be continued later
                    InterpretedCode.AddValue(valueT)         
                    continue
                    
                #other case
                self.SetVar(vars,'TEMPORARY_VARS'+str(allow_recursion),A)
                JScode = 'TEMPORARY_VARS'+str(allow_recursion) + JScode

            #2 - Alpha chain
            elif c == '"' or c == "'":

                ee = GetItemAlone(JScode,c)
                e = len(ee)
                vv = ee[1:-1]
                
                # raw string cannot end in a single backslash
                #if vv[-1:] == '\\' and  not vv[-2:-1] == '\\':
                #    vv = vv + '\\'
                    
                #warning with this function
                #if not vv.endswith('\\'):
                #    vv = vv.decode('string-escape')
                
                JScode = JScode[(e):]
                
                #to be faster
                if len(JScode) == 0:
                    InterpretedCode.AddValue(vv)
                    continue
                #normal way
                else:
                    self.SetVar(vars,'TEMPORARY_VARS'+str(allow_recursion),vv)
                    JScode = 'TEMPORARY_VARS'+str(allow_recursion) + JScode
                  

            item = ''
            #5 Variable/fonction/object
            P1 = JsParserHelper1('TEMPORARY_VARS'+str(allow_recursion))
            while(P1.process(JScode)):
                JScode = P1.rest_code
                r = None
                
                if P1.t == 'var':
                
                    #special vars
                    if P1.name== 'window' and P1.at1:
                        P1.name = RemoveGuil(P1.at1)
                        P1.at1= ''
                        
                    Var_string = P1.name
                    if P1.at1:
                        Var_string = "%s[%s]" % (P1.name, str(P1.at1) )
                        
                    #operation / creation ?
                    if P1.op:    
                        out('creation/modification ' + Var_string + ' ' + P1.op )
                        r,JScode = self.VarParser(vars,allow_recursion,Var_string,P1.op,JScode)
                        
                    else:
                        if not self.IsVar(vars,P1.name):
                            self.PrintVar(vars)
                            raise Exception('Variable error : ' + P1.name)

                        r = self.GetVar(vars,Var_string)
                
                elif P1.t == 'fct':
                    if P1.at1:
                        fonction = P1.at1
                        name = P1.name
                    else:
                        fonction = P1.name
                        name = ''

                    if P1.eval:   
                        fonction = self.evalJS(fonction,vars,allow_recursion)

                    #hack, devrait etre acive tout le temps
                    if 'TEMPORARY_VARS' in name:
                        name = self.evalJS(name,vars,allow_recursion)

                    r,JScode = self.FonctionParser(vars,allow_recursion,name,fonction,P1.arg,JScode)
                
                #to speed up
                if not JScode:
                    InterpretedCode.AddValue(r)
                    continue                    
                #normal way
                else:
                    self.SetVar(vars,'TEMPORARY_VARS'+str(allow_recursion),r)
                    JScode = 'TEMPORARY_VARS'+str(allow_recursion) + JScode
            
            #after this part, all TEMPORARY_VARS need to be removed
            if JScode.startswith('TEMPORARY_VARS'+str(allow_recursion)):
                r = self.GetVar(vars,'TEMPORARY_VARS'+str(allow_recursion))
                self.InitVar(vars,'TEMPORARY_VARS'+str(allow_recursion))
                JScode = JScode[(len('TEMPORARY_VARS'+str(allow_recursion))):]
                InterpretedCode.AddValue(r)
                continue     
            if P1.used:
                continue
                
            # --var method, HACK
            if JScode[0:2] == '--' or JScode[0:2] == '++':
                m = re.search('^(\({0,1}\w[\w\.]*\){0,1} *(?:\[[^\]]+\])* *)(' + REG_OP + '|\[|$)',JScode[2:], re.UNICODE)
                if m:
                    l = len(m.group(1))
                    JScode = m.group(1) +JScode[0:2] + JScode[(l+2):]
                    continue
                else:
                    bb(mm)

            #Space to remove
            if c == ' ' or c == '\n':
                JScode = JScode[1:]
                continue
                
            #Escape char
            if c == '\\':
                JScode = JScode[1:]
                continue
                
            #Special if (A)?(B):(C)
            if c == '?':
                out( " ****** Special if 1 ********* ")
                #need to find all part
                A = InterpretedCode.GetPrevious()
                B = GetItemAlone(JScode,':')
                C = GetItemAlone(JScode[(len(B) + 1):])
                
                Totlen = len(B) + len(C) + 2
                B = B[1:]
                if B.startswith('('):
                    B = B[1:-1]
                if C.startswith('('):
                    C = C[1:-1]               
                if A:
                    r = self.evalJS(B,vars,allow_recursion)
                else:
                    r = self.evalJS(C,vars,allow_recursion)

                InterpretedCode.AddValue(r)
                JScode = JScode[Totlen :]
                continue

            #Short-circuiting evaluations
            if JScode[0:2] == '&&' or JScode[0:2] == '||':
                out( " ****** Short-circuiting  ********* ")
                A = InterpretedCode.GetPrevious()
                B = GetItemAlone(JScode[2:])
                
                Totlen = len(B) + 2
                if B.startswith('('):
                    B = B[1:-1]
                    
                #for && if the first operand evaluates to false, the second operand is never evaluated
                if JScode[0:2] == '&&':
                    if A:
                        r = self.evalJS(B,vars,allow_recursion)
                        InterpretedCode.AddValue(r)
                    else:
                        InterpretedCode.AddValue(A)
                #for || if the result of the first operand is true, the second operand is never operated
                if JScode[0:2] == '||':
                    if not A:
                        r = self.evalJS(B,vars,allow_recursion)
                        InterpretedCode.AddValue(r)
                    else:
                        InterpretedCode.AddValue(A)
                        
                JScode = JScode[Totlen :]
                continue
                
            #Operation
            if c in '+<>-*/=&%|!^.':
                InterpretedCode.SetOp(c)
                JScode = JScode[1:]
                continue      
                
            #No sure how to put this
            if JScode == '{}':
                InterpretedCode.AddValue({})
                JScode = JScode[2:]
                continue
            if JScode == '[]':
                InterpretedCode.AddValue([])
                JScode = JScode[2:]
                continue
        
            #???
            if JScode == ';':
                JScode = JScode[1:]
                continue
                
            #comma
            if c == ',':
                InterpretedCode.GetPrevious()
                JScode = JScode[1:]
                continue
                
            # Not found part
            # We will make another turn
            self.PrintVar(vars)
            out("Can't eval string :" + JScode)
            out("Last eval : " + str(self.LastEval))

            #print debug.encode('ascii','replace')
            raise Exception(str(allow_recursion) + " : Can't Eval chain : " + JScode)

        InterpretedCode2 = InterpretedCode.GetBuffer()
        
        out( str(allow_recursion) + ' : Evalue > '+ Ustr(InterpretedCode2) + " type " + Ustr(type(InterpretedCode2)) )
        out( '-------------')

        self.LastEval = InterpretedCode2
        return InterpretedCode2

        
    def InitVar(self,var,variable):
        variable = variable.strip()
    
        for j in var:
            if j[0] == variable:
                var.remove(j)
                return
    
        
    def GetVar(self,var,variable):
    
        #variable = variable.strip()
        
        index = None
        if '[' in variable:
            index = GetItemAlone(variable[(variable.find('[')):],']')
            index = index[1:-1]
            variable = variable.split('[')[0]
            index = self.evalJS(index,var,50)
            
        if '.' in variable:
            index = variable.split('.')[1]
            variable = variable.split('.')[0]
            
        #out('Variable Get ' + variable + ' index :' + str(index))
        
        for j in var:
            if j[0] == variable:
                k = j[1]
                r = k
                if not(index == None):
                    if type(k) in [list,tuple,str]:
                        if CheckType(index) == 'Numeric':
                            if int(index) < len(k):
                                r = k[int(index)]
                            else:
                                r = 'undefined'
                        elif CheckType(index) == 'String':
                            index = RemoveGuil(index)
                            if index == 'length':
                                r = len(k)
                            else:
                                try:
                                    r = k[index]
                                except:
                                    r = k[int(index)]
                    elif type(k) in [dict]:
                        index = RemoveGuil(index)
                        r = k.get(index) 
                    elif type(k) in [type]:
                        r = getattr(k(self,None), index)
                return r
                
        #search it in hackvar ?
        for j in self.HackVars:
            if j[0] == variable:
                return j[1]
                
        #search in fonction in lib, Hack again
        #for lib in List_Lib:
        #    if variable == str(lib.__name__):
        #        return lib
                
        raise Exception('Variable not defined: ' + str(variable))
            
    def SetVar(self,var,variable,value,i = None):
    
        #print 'Setvar Variable =' + variable + ' value=' + str(value) + ' index=' + str(i)

        variable = variable.strip()
        
        #cleaning
        #if variable[0] == '(':
        #    variable = variable[1:-1]

        #Existing var ?
        for j in var:
            if j[0] == variable:

                if i == None:
                    #vars ?
                    if (isinstance(value, types.StringTypes)):
                        var[var.index(j)] = (variable,value)
                    #Numeric
                    else:
                        var[var.index(j)] = (variable,value)
                else:   
                #Array 
                    if type(var[var.index(j)][1]) in [list,tuple]:

                        Listvalue = var[var.index(j)][1]

                        #ok this place doesn't esist yet
                        l = int(i) - len(Listvalue) + 1
                        while l > 0:
                            Listvalue.append('undefined')
                            l -= 1
                        #Now modify it
                        if type(value) in [list,tuple]:
                            Listvalue = value
                        else:
                            Listvalue[int(i)] = value
                        var[var.index(j)] = (variable,Listvalue)
                    #dictionnary
                    elif type(var[var.index(j)][1]) in [dict]:
                        Listvalue = var[var.index(j)][1]
                        Listvalue[i] = value
                        var[var.index(j)] = (variable,Listvalue)

                return
                
        #New var
        var.append((variable,value))
        
    def GetTypeVar(self,var,variable):
        try:
            variable = variable.split('[')[0]
            variable = variable.split('.')[0]
            for j in var:
                if j[0] == variable:
                    return type(j[1])
            return 'Undefined'
        except:
            return 'Undefined'   
    
    def IsVar(self,var,variable,index = None):
        try:
            variable = variable.split('[')[0]
            variable = variable.split('.')[0]
            for j in var:
                if j[0] == variable:
                    if index == None:
                        return True
                    if index in var[var.index(j)][1]:
                        return True
                        
            return False
        except:
            return False
        
    #Need to use metaclass here
    def IsFunc(self,vars,name):
        bExist = False
        bExist = self.IsVar(vars,name)
        if not bExist:
            return False
            
        f = self.GetVar(vars,name)
        if f == '$':
            return '$'
        if isinstance(f, fonction):
            return f
        elif isinstance(f, types.MethodType):
            return f
        else:
            return self.IsFunc(vars,f)
        
    def VarManage(self,allow_recursion,vars,name,value=None):

        index = None
        init = False
        
        #out('Variable manager name: ' + str(name) + ' value: ' + str(value) + ' ' + str(type(value)))
        
        try:
            value = value.strip()
        except:
            pass
        name = name.strip()
        
        #variable is an object
        if '.' in name:
            if self.GetTypeVar(vars,name) == 'tuple':
                index = name.split('.')[1]
                name = name.split('.')[0]
        #Variable is an array ?
        m = re.search(r'^\({0,1}([\w]+)\){0,1}\[(.+?)\]$', name,re.DOTALL | re.UNICODE)
        if m:
            name = m.group(1)
            index = m.group(2)
            index = self.evalJS(index,vars,allow_recursion)
            
        #if name.startswith('('):
        #    name = name[1:-1].strip()
  
        if value:
            if isinstance(value, ( int, long , float) ):
                value = self.evalJS(value,vars,allow_recursion)
            else:
                #Values is an array []
                if value.startswith('[') and value.endswith(']'):
                    value = value[1:-1]
                    
                    #hack
                    if value == '':
                        value = []
                    #normal way
                    else:  
                        valueT = MySplit(value,',')
                        v = []
                        for k in valueT:
                            v2 = self.evalJS(k,vars,allow_recursion)
                            v.append(v2)
                        value = v
                        if index == None:
                            index = 0
                            init = True
                #Values is an array {}
                elif value.startswith('{') and value.endswith('}'):
                    value = value[1:-1]
                    valueT = MySplit(value,',',True)
                    v = {}
                    for k in valueT:
                        l = k.split(':')
                        #WARNING : no eval here in JS
                        #v2g = self.evalJS(l[0],vars,func,allow_recursion)
                        v2g = RemoveGuil(l[0])
                        v2d = self.evalJS(l[1],vars,allow_recursion)
                        v[v2g] = v2d
                    value = v
                    if index == None:
                        index = 0
                        init = True
                #string and other            
                else:
                    value = self.evalJS(value,vars,allow_recursion)

        name = name.strip()


        #Output for debug
        if not (index == None):
            out( '> Variable in parser => ' + Ustr(name) + '[' + Ustr(index) + ']' + ' = ' + Ustr(value))
        else:
            out( '> Variable in parser => ' + Ustr(name) + ' = ' + Ustr(value))
                           
        #chain
        if (isinstance(value, types.StringTypes)):
            self.SetVar(vars,name,value,index)
        #number
        elif isinstance(value, ( int, long , float) ):
            self.SetVar(vars,name,value,index)
        #list
        elif type(value) in [list,tuple,dict]:
            if init:
                self.InitVar(vars,name)
            self.SetVar(vars,name,value,index)
        #fonction
        elif isinstance(value, fonction):
            self.SetVar(vars,name,value,index)        
        #undefined
        elif value == None:
            self.SetVar(vars,name,None,index)
        else:
            print type(value)
            raise Exception('> ERROR : Var problem >' + str(value))
        return
        

    #(Function(arg){code})(arg2) Self invoked
    #(Function(arg){code}(arg2)) Self invoked
    # Function(arg){code}(arg2)  Self invoked 
    def MemFonction(self,vars,name,parametres,openparenthesis,data):
    
        if not name:
            n0 = 0
            while self.IsFunc(vars,'AnonymousFunc' + str(n0)):
                n0=n0+1
            name = 'AnonymousFunc' + str(n0)
            
        if (self.SpecialOption):
            if self.SpecialOption.split('=')[0] == 'Namefunc':
                name = self.SpecialOption.split('=')[1]
            self.SpecialOption = ''
             
        param = MySplit(parametres,',',True)
        
        out('Extract function :' + name + ' ' + str(param))
        #out('data ' + str(data))
        
        pos = 0
        replac = ''
        
        while not data[0] == '{':
            data = data[1:]
        
        content = GetItemAlone(data,'}')[1:-1]
        pos2 = len(content) + 1
        
        fm = fonction(name,param,content.lstrip())
        self.SetVar(vars,name,fm)
        
        data = data[(pos2+1):]
        
        if openparenthesis:
            c,p = GetNextUsefullchar(data)
            if c == ')':
                data = data[(p+1):]
                openparenthesis = False

        selfinvoked = False
        if len(data) > 0:
            if data[0] == '(':
                selfinvoked = True

        #self invoked ?
        if selfinvoked:
            paraminvoked = GetItemAlone(data,')')
            out( "Self invoked " + str(paraminvoked) )
            replac = name + paraminvoked
            
            data = data[(len(paraminvoked)):]
            
            if openparenthesis:
                c,p = GetNextUsefullchar(data)
                if c == ')':
                    data = data[(p+1):]
                    openparenthesis = False

        replac = replac + data
          
        return replac, 0 , name
        
    def Parse(self,JScode,vars,allow_recursion=MAX_RECURSION):
    
        if allow_recursion < 0:
            raise Exception('Recursion limit reached')
            
        allow_recursion -= 1
    
        #************************
        #    Post traitement
        #************************
        
        #Need all functions first, because they can be called first and be at the bottom of the code
        #So we extract all functions first, and replace them by a simple call in the code, if they are self invoked
        
        #Make this part only if needed
        if 'function' in JScode:
            posG = 0
            Startoff = 0
            Endoff = 0
        
            while (True):

                chain,pos = self.ExtractFirstchain(JScode[posG:])
                if not (chain):
                    break
                
                Startoff = posG
                Endoff = posG + pos + 1
                posG = Endoff
                
                #skip empty char
                chain = chain.strip()
                 
                #out('/////////////////')
                #out('> ' + chain)
                #out('/////////////////')
                
                #fonction
                m = re.search(r'^(\()* *function(?: ([\w]+))* *\(([^\)]*)\) *{', chain,re.DOTALL)
                if m:
                    name = ''
                    openparenthesis = False
                    if m.group(2):
                        name = m.group(2)
                    if m.group(1):
                        openparenthesis = True
                
                    replac,pos3,xyz = self.MemFonction(vars,name,m.group(3),openparenthesis,chain)
                    
                    JScode = JScode[:Startoff]+ replac + JScode[Endoff:]
                    
                    posG = Startoff + len(replac)

        #***********************
        # The real Parser
        #**********************

        Parser_return = None
        
        while (True):
        
            if self.continu:
                break;
        
            chain,pos = self.ExtractFirstchain(JScode)
            if not (chain):
                break
                
            JScode = JScode[(pos+1):]
                        
            chain = chain.lstrip().rstrip()
            
            #empty ?
            if chain == ';':
                continue
              
            out( 'D++++++++++++++++++' )
            out(chain.encode('ascii','replace') )
            out( 'F++++++++++++++++++')
            
            #hackVars ?
            m = re.search(r'^\$\("#([^"]+)"\)\.text\(([^\)]+)\);', chain)
            if m:
                out( '> hack ' + m.group(0) + ' , variable est ' + m.group(1))
                self.SetVar(self.HackVars,m.group(1),self.GetVar(vars,m.group(2)))
                continue
                
            #break
            if chain.startswith('break'):
                self.Break = True
                return
                
            #continue
            if chain.startswith('continue'):
                self.continu = True
                return
            
            #Return ?                
            if chain.startswith('return'):
                m = re.match(r'return *;', chain)
                if m:
                    self.Return = True
                    self.ReturnValue = None
                    return
                m = re.match(r'^return *([^;]+)', chain)
                if m:
                    chain = m.group(1)
                    r = self.evalJS(chain,vars,allow_recursion)
                    self.Return = True
                    self.ReturnValue = r
                    return
                    
            #Variable creation/modification ?
            #m =  re.search(r'^\({0,1}([\w\.]+)\){0,1}(?:\[([^\]]+)\])*\){0,1}\s*(?:[\^\/\*\-\+])*=',chain,re.DOTALL | re.UNICODE)
            #m2 = re.search(r'^\({0,1}([\w\.]+)\){0,1}(?:\.([\w]+))*\){0,1}\s*(?:[\^\/\*\-\+])*=',chain,re.DOTALL | re.UNICODE)
            if chain.startswith('var '):
                out('var')

                chain = chain[4:]
                
                #Now need to extract all vars from chain
                while (chain):
                    v1 = GetItemAlone(chain,',').strip()
                    chain=chain[(len(v1) + 1):]
                    if v1.endswith(',') or v1.endswith(';'):
                        v1 = v1[:-1]
                    self.evalJS(v1,vars,allow_recursion)                      
                continue

            name = ''            
            #Extraction info
            #Problem, catch fonction too :(
            m = re.search(r'^([\w]+) *(\(|\{)', chain,re.DOTALL)
            #Syntax > aaaaa(bbbbb) .........
            if m:
                name = m.group(1)
                sp = m.group(2)
                if sp == '(':
                    arg = GetItemAlone(chain[(m.end()-1):],')')[1:-1]
                    pos3 = len(arg) + 1
                    
                    code = chain[(m.end() + pos3):]
                elif sp == '{':
                    arg = ''
                    code = chain[(m.end()-1):]
                else:
                    raise Exception('> Er 74')
                
                out( 'DEBUG > Name: ' + name + ' arg: ' + arg + ' code: ' + code + '\n' )
                
                #Jquery
                if name == 'DOCUMENT_READY':
                    out('DOCUMENT_READY ' + arg)
                    self.SpecialOption = 'Namefunc=DR'
                    self.Parse(arg,vars,allow_recursion)

                    #It's not the correct place to do that, but for the moment ...
                    self.Parse('DR();',vars,allow_recursion)
                    
                    continue

                #For boucle ?
                if name == 'for':
                    arg = arg.split(';')
                    v = arg[0] + ';'
                    t = arg[1]
                    i = arg[2] + ';'
                    f = code
                    if GetNextUsefullchar(f)[0] =='{':
                        f = GetItemAlone(f,'}')[1:-1]
                    
                    #out('> Boucle for : Var=' + v + ' test=' + t + ' incrementation=' + i + ' code=' + f)
                    
                    #init var              
                    self.Parse(v,vars,allow_recursion)
                    #loop
                    while (self.CheckTrueFalse(self.evalJS(t,vars,allow_recursion))):
                        #fonction
                        self.Parse(f,vars,allow_recursion)
                        if self.Break:
                            self.Break = False
                            break
                        #incrementation
                        self.Parse(i,vars,allow_recursion)

                    continue
                    
                #boucle while ?
                if name == 'while':
                    f = code
                    if GetNextUsefullchar(f)[0] =='{':
                        f = GetItemAlone(f,'}')[1:-1]
                    
                    #out('> Boucle while : Var=' + v + ' test=' + t + ' incrementation=' + i + ' code=' + f)
                    
                    #loop
                    while (self.CheckTrueFalse(self.evalJS(arg,vars,allow_recursion))):
                        #fonction
                        self.Parse(f,vars,allow_recursion)
                        if self.Break:
                            self.Break = False
                            break
                            
                        if self.continu:
                            self.continu = False

                    continue
                    
                #boucle do/while
                if name == 'do':
                    f = code
                    e = ''
                    if sp =='{':
                        f = GetItemAlone(f,'}')
                    
                    if f.startswith('{'):
                        f = f[1:-1]
                        
                    #Need to check the while part ?
                    chain2,pos2 = self.ExtractFirstchain(JScode)
                    if 'while' in chain2:
                        chain2 = chain2.lstrip()
                        JScode = JScode[(pos2 + 1):]
                        m2 = re.search(r'while\s*\((.+?)\);$', chain2,re.DOTALL)
                        if m2:
                            e = m2.group(1)
                        
                    if not e:
                        raise Exception('> While error')
                        
                    out('> Boucle do/while : test :' + e + ' code: ' + f)
                    
                    #loop
                    #1 forced execution because do/while
                    self.Parse(f,vars,allow_recursion)
                    if self.Break:
                        self.Break = False
                        continue #stop all
                        
                    if self.continu:
                        self.continu = False
                    #and now the loop
                    while (self.CheckTrueFalse(self.evalJS(e,vars,allow_recursion))):
                        #fonction
                        self.Parse(f,vars,allow_recursion)
                        if self.Break:
                            self.Break = False
                            break
                            
                        if self.continu:
                            self.continu = False

                    continue                    
                #boucle switch
                if name == 'switch':
                    v = self.evalJS(arg,vars,allow_recursion)
                    f = code[1:]
                    
                    if v == 'undefined':
                        continue
                         
                    #out('> Boucle switch : Case=' + v + ' code= ' + f[0:50] + '\n')
                    #logwrite(str(v) + '\n')

                    #Search the good case code
                    StrToSearch = "case'%s':"%(str(v))
                    
                    while ((not f.startswith(StrToSearch)) and (len(f) > 0)):
                        tmp_str = GetItemAlone(f,';}')
                        f = f[(len(tmp_str)+1):]

                    if len(f) < 1:
                        self.PrintVar(vars)
                        raise Exception("Can't find switch value " + str(v))
                        
                    f = f[(len(StrToSearch)):]
                        
                    #out('\n> New block : ' + f[0:50])
                    
                    self.Parse(f,vars,allow_recursion)
                    
                    continue
                    
                #Boucle if
                if name == 'if':
                    t = arg
                    f = code
                    e = ''
                    
                    if GetNextUsefullchar(f)[0] =='{':
                        f = GetItemAlone(f,'}')[1:-1]

                    #Need to check if there is else statement ?
                    chain2,pos2 = self.ExtractFirstchain(JScode)
                    if 'else' in chain2:
                        chain2 = chain2.lstrip()
                        JScode = JScode[(pos2 + 1):]
                        m2 = re.search(r'else\s*{(.+?)}$', chain2,re.DOTALL)
                        if m2:
                            e = m2.group(1)
                    
                    #out('> Boucle if : test=' + arg + ' code=' + f + ' else=' + e)
                    
                    #hack, need to memorise working test in future
                    if self.option_ForceTest:
                        try:
                            ttt = self.CheckTrueFalse(self.evalJS(t,vars,allow_recursion))
                        except:
                            from random import choice
                            ttt = choice([True,False])
                            #thx to come every day, to help me to find bug on this code
                            
                        if (ttt):
                            self.Parse(f,vars,allow_recursion)
                        elif (e):
                            self.Parse(e,vars,allow_recursion)
                        continue
                    #normal way
                    else:
                        if (self.CheckTrueFalse(self.evalJS(t,vars,allow_recursion))):
                            self.Parse(f,vars,allow_recursion)
                        elif (e):
                            self.Parse(e,vars,allow_recursion)
                        continue
                    
                if name == 'with':
                    f = code
                    if GetNextUsefullchar(f)[0] =='{':
                        f = GetItemAlone(f,'}')

                    #list all arg membre.
                    member_list = self.GetVar(vars,arg)
                    
                    out('> With fonction : exp=' + arg + ' values=' + str(member_list))
                    #print 'Before: ' + f
                    
                    #print member_list
                    
                    def sub(g):
                        g = g.group()
                        return g[0] + arg + '["' + g[1:-1] + '"]' + g[-1:]
                    
                    #Hack again
                    if type(member_list) in [type]:
                        for i in member_list.__dict__:
                             f = re.sub(r'[^\w]' + str(i) + '[^\w]',sub,f,re.DOTALL)
                    else:
                        for i in member_list:
                            f = re.sub(r'[^\w]' + i + '[^\w]',sub,f,re.DOTALL)
                        
                    #print 'after: ' + f        
                    
                    self.Parse(f[1:-1],vars,allow_recursion)
                    #JScode = f[1:-1] + ';' + JScode
                    continue   
                    
            #Pas trouve, une fonction ?
            if chain.endswith(';'):
                Parser_return = self.evalJS(chain[:-1],vars,allow_recursion)

            #hack, need to be reenabled
            #Non gere encore
            if not chain.endswith(';'):
                print '> ' + JScode
                raise Exception('> ERROR : can t parse >' + chain)
            
        return Parser_return

    def ProcessJS(self,JScode,vars = []):
        vars_return = []
        
        if (False):
            out('Unicode convertion')
            JScode = unicode(JScode, "utf-8")
            self.Unicode = True
        
        #Special
        vars.append(('Math',Math))
      
        vars.append(('String',''))
        vars.append(('document',{'write':'ok'}))
        
        #Hack
        JScode = JScode.replace('$(document).ready','DOCUMENT_READY')
        #JScode = JScode.replace('.length','.length()')
        
        #Start the parsing
        ret = self.Parse(JScode,vars)
        
        #Memorise vars
        
        
        return ret
		

def toStr(str):
    def decorator(f):
        class _temp:
            def __call__(self, *args, **kwargs):
                return f(self.real_self, *args, **kwargs)
            def __str__(self):
                return str%f.__name__
        return _temp()
    return decorator


class Math(object):
    def __init__(self,initV1,initV2):
        pass

    def max(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        return max(t1,t2)
        
    def min(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        return min(t1,t2)
        
    def abs(self,arg):
        return abs(arg[0])

    def pow(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        return pow(t1,t2)
        
    @toStr("function %s() {\n    [native code]\n}")
    def sin(self,arg):
        return math.sin(arg[0])
    
    @toStr("function %s() {\n    [native code]\n}")
    def atan(self,arg):
        return math.atan(arg[0])
         
    def __contains__(self,arg):
        if arg in ['max','min','abs','pow','sin','atan']:
            return True
        return False

class String(object):
    def __init__(self,initV1,initV2=''):
        self._JSParser = initV1
        self._string = initV2

    def Get(self):
        return self._string

    def charCodeAt(self,arg):
        v = arg[0]
        return ord(self._string[int(v)])

    def length(self,arg):
        return len(self._string)

    def substring(self,arg):
            p1 = arg[0]
            if len(arg)> 1:
                p2 = arg[1]
                return self._string[ int(p1) : int(p2) ]
            else:
               return self._string[ int(p1) :]

    def replace(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        
        #if not t1.startswith('/'):
        #    t1 = self.evalJS(t1,vars,allow_recursion)
            
        #regex mode ? HACK
        if t1.startswith('/'):
            jr = re.findall(t1.split('/')[1], self._string)

            for k in jr:
                if not self._JSParser.IsFunc(self._JSParser.FastEval_vars,t2):
                    self._string = self._string.replace(k,t2)
                    out('Replace (F) ' + str(k) + " by " + str(t2))
                else:
                    v = self._JSParser.Fast_Eval(t2+'('+ k + ')')
                    v = str(v)
                    self._string = self._string.replace(k,v)
                    out('Replace ' + str(k) + " by " + str(v))
        #String mode
        else:
            #t1 = self.evalJS(t1,vars,func,allow_recursion)
            self._string = s.replace(t1,t2)
        return self._string
            
    def fromCharCode(self,arg):
        return chr(int(arg[0]))

    def split(self,arg):
        arg = arg[0].replace('"','').replace("'","")
        if arg == '':
            return list(self._string)
        else:
            return self._string.split(arg)
            
    def indexOf(self,arg):
        start = 0
        if len(arg) > 1:
            start = int(arg[1])
        return self._string.find(arg[0], start)

class Array(object):
    def __init__(self,initV1,initV2=[]):
        self._array = initV2
        
    def Get(self):
        return self._array
        
    def join(self,arg):
        t = arg[0].replace('"','').replace("'","")
        return t.join(self._array)

    def push(self,arg):
        t1 = arg[0]
        if len(arg) > 1:
            #use s.extend-[array]);
            raise Exception("Not implemented - push")
        self._array.append(t1)

        v = len(self._array)
        return v
        
    def slice(self,arg):
        p1 = arg[0]
        if len(arg)> 1:
            p2 = arg[1]
            sr = self._array[int(p1):int(p2)]
        else:
            sr = self._array[int(p1):]
        sr = '"' + sr + '"'
        return sr
        
    def splice(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        if len(arg) > 2:
            raise Exception("Not implemented - splice")
        tab = self._array[:t1] + self._array[(t1 + t2):]
        tabsup = self._array[t1:(t1 + t2)]

        self._array = tab
        return tabsup

    def shift(self,arg):
        if len(self._array) == 0:
            return None
        return self._array.pop(0)
                        
class Basic(object):
    def __init__(self,initV1,initV2):
        self._JSParser = initV1
        self._name = initV2
        pass
        
    def Setting(self,vars):
        self._vars=vars
        
    def parseInt(self,arg):
        t1 = arg[0]
        t2 = arg[1]
        if t1 == '':
            return None
        r = int(t1,int(t2))
        return r
        
    def typeof(self,arg):
        return type(arg)
        
    def debug(self,arg):
        print '------------------------------------'
        self._JSParser.PrintVar(self._JSParser.FastEval_vars)
        print '------------------------------------'
        raise Exception("DEBUG")        
        return
        
    def eval(self,arg):
        out('To eval >' + arg)
        r = self._JSParser.Parse(RemoveGuil(arg),self._JSParser.FastEval_vars,self._JSParser.FastEval_recur)
        return r
       
    def Array(self,arg):
        if arg[0]:
            if isinstance(arg[0], ( int, long ) ):
                return []
            return arg
        return []  

    def alert(self,arg):
            #t1 = self.evalJS(arg,vars,allow_recursion)
            #logwrite(str(arg))
            print '------------ALERT-------------------'
            print arg
            print '------------------------------------'
            return ''

    def RegExp(self,arg):
        t1 = RemoveGuil(arg[0])
        t2 = RemoveGuil(arg[1])
        return '/' + t1 + '/' + t2
        
    #this fonction if for object normaly
    def toString(self,arg):
        t1 = arg[0]
        try:
            f = self._name.im_func.__name__
        except:
            f = "HACK'"
        t = "function %s() {\n    [native code]\n}"%(f)
        return t
    
  

List_Lib = [Basic,Array,String,Math]

#****************************************************************
#openload *******************************************************
#****************************************************************


def myrequest(url, postfields = {}, headers = {}, cookie = 'cookie.lpw', loc = None, useragent = ''):
    """
        url = 'http://www.diziizleyin.net/index.php?x=isyan'
        postfields = {'pid' : 'p2x29464a434'}
        txheaders = {'X-Requested-With':'XMLHttpRequest'}
        myrequest(url, postfields, txheaders, loc)
    """
    if not useragent:
        useragent = UA
    url = url if url.startswith('http://') else 'http://' + url
    req = urllib2.Request(url)
    cj = cookielib.LWPCookieJar()
    if os.path.isfile('cookie.lpw'):
        cj.load('cookie.lpw')
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    if postfields:
        postfields = urllib.urlencode(postfields)
        req = urllib2.Request(url, postfields)
    req.add_header('User-Agent', useragent)
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)

    response = urllib2.urlopen(req)
    if loc:
        data = response.geturl()
        response.close()
    else:
        data = response.read()
        response.close()
        cookiepath = 'cookies.lwp'
        addonId = "plugin.video.turkvod"
        dataroot = xbmc.translatePath('special://profile/addon_data/%s' % (addonId)).decode('utf-8')
        cj.save( os.path.join( dataroot, cookiepath ) )		
    return data


class urlKap(object):
    """
        urlKap(url).result
        urlKap(url, output = 'geturl').result
        urlKap(url, output = 'cookie').result
        urlKap(url, timeout='30').result
        post = {'hash':media_id}
        urlKap(url, post = post).result
        url = 'http://www.diziizleyin.net/index.php?x=isyan'
        postfields = {'pid' : 'p2x29464a434'}
        txheaders = {'X-Requested-With':'XMLHttpRequest'}
        urlKap(url, postfields, headers, loc)
    """

    def __init__(self, url, close = True, proxy = None, post = None, mobile = False, referer = None, cookie = None, output = '', timeout = '10'):
        if not proxy == None:
            proxy_handler = urllib2.ProxyHandler({'http': '%s' % proxy})
            opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
            opener = urllib2.install_opener(opener)
        if output == 'cookie' or output == 'kukili' or not close == True:
            import cookielib
            cookie_handler = urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar())
            opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
            opener = urllib2.install_opener(opener)
        if not post == None:
            post = urllib.urlencode(post)
            request = urllib2.Request(url, post)
        else:
            request = urllib2.Request(url, None)
        if mobile == True:
            request.add_header('User-Agent', 'Mozilla/5.0 (iPhone; CPU; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')
        else:
            request.add_header('User-Agent', UA)
        if not referer == None:
            request.add_header('Referer', referer)
        if not cookie == None:
            request.add_header('cookie', cookie)
        response = urllib2.urlopen(request, timeout=int(timeout))
        if output == 'cookie':
            result = str(response.headers.get('Set-Cookie'))
        elif output == 'kukili':
            result = response.read() + 'kuki :' + str(response.headers.get('Set-Cookie'))
        elif output == 'geturl':
            result = response.geturl()
        elif output == 'lenght':
            result = str(response.headers.get('Content-Length'))
        else:
            result = response.read()
        if close == True:
            response.close()
        self.result = result


class turkvod_parsers:

    def __init__(self):
        self.quality = ''
        mydebug()

    def get_parsed_link(self, url):
        if url.startswith('//www.'):
            url = 'http:' + url
        elif url.startswith('www.'):
            url = 'http://' + url
        elif url.startswith('//'):
            url = 'http:' + url
        son_url = ''
        film_quality = []
        video_tulpe = []
        error = None
        try:
		
            if 'vidlox' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    for match in re.finditer('"(http[^"]+(m3u8|mp4))"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'strdef' in url:
                try:
                    def decode_base64(data):
                        missing_padding = len(data) % 4
                        if missing_padding != 0:
                            data += b'='* (4 - missing_padding)
                        return base64.decodestring(data)

                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer': url }
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    link = re.findall('document.write\(dhYas638H\(dhYas638H\("([^"]+)"', data)[0]
                    dd = (decode_base64(link))
                    cc = (decode_base64(dd))
                    link2 = re.findall('document.write\(dhYas638H\(dhYas638H\("([^"]+)"', cc)[0]
                    ee = (decode_base64(link2))
                    ff = (decode_base64(ee))
                    url = re.search(r'iframe src="([^"]+)"', ff, re.IGNORECASE).group(1)					
                    son_url = self.get_parsed_link(url)

                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'izletv' in url:
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                        'Connection':'keep-alive',
                        'Accept': '*/*',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'X-Requested-With':'XMLHttpRequest',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Accept-Language': 'tr-TR,tr;q=0.8,en-US;q=0.5,en;q=0.3',
                        'Referer': url}
                    html = urlKap(url).result
                    hash, id = re.findall('live\("([^"]+)","([^"]+)"\); }\);\s+</script>', html, re.IGNORECASE)[0]
                    post = {'hash': hash, 'id': id}
                    link = urlKap(url, HTTP_HEADER, post = post).result
                    link1 = link [::-1]
                    def decode_base64(data):
                        missing_padding = len(data) % 4
                        if missing_padding != 0:
                            data += b'='* (4 - missing_padding)
                        return base64.decodestring(data)
                    son_url1 = decode_base64(link1)  
                    Header = '|Referer='+url+'&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Mobile Safari/537.36&Cookie=__cfduid=d663e7591ad23148f58f1396c79fc7be41516555703&Connection=keep-alive'
                    son_url = son_url1 + Header
                except Exception as ex:
                    print ex
		
            if '24video' in url:
                try:
                    media_id = re.findall('embedPlayer/([A-Za-z0-9]+)', url, re.IGNORECASE)[0]
                    weburl = 'http://www.24video.adult/video/xml/' + media_id + '?mode=play'
                    html = myrequest(weburl)
                    son_url = re.findall('video url=[\'|"](.*?)[\'|"]', html)[0]
                    son_url = son_url.replace('&amp;', '&')
                except Exception as ex:
                    print ex

            if 'bitporno' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    for match in re.finditer('"file":"(http[^"]+)","label":"([^"]+)"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1).replace('\\', ''))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'camtubechat' in url:
                try:
                    html = myrequest(url)
                    son_url = re.findall("src='(.*?m3u8.*?)&amp", html)[0]
                    son_url = son_url.replace('_fast_aac', '_aac')
                except Exception as ex:
                    print ex

            if 'ligtvjet' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall('iframe src="([^"]+)"', response)
                    request2 = urllib2.Request(link[0], None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request2).read()
                    link2 = re.findall("source: '([^']+)'", response)
                    son_url1 = link2[0]
                    if son_url1.startswith("//"):
                        son_url1 = "http:" + son_url1
                    son_url = son_url1
                except Exception as ex:
                    print ex

            if 'canlitv.com' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall('file: "(.*?)"', response)
                    son_url1 = link[0]
                    if son_url1.startswith("//"):
                        son_url1 = "https:" + son_url1
                    son_url = son_url1

                except Exception as ex:
                    print ex

            if 'canlitvlive' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    stlink = re.findall('(www.canlitvlive.(?:io|site)/tvizle.php\?t=[^"]+)"', html, re.IGNORECASE)[0]
                    stlink = 'http://' + stlink
                    request = urllib2.Request(stlink, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall('file(?: |):(?: |)"(.*?)"', response)
                    son_url1 = link[0]
                    if son_url1.startswith("//"):
                        son_url1 = "http:" + son_url1
                    Header = '|Referer='+url+'&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Mobile Safari/537.36'
                    son_url = son_url1 + Header
                except Exception as ex:
                    print ex
					
            if 'closeload' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    #packed = re.findall('(eval\\(function.*?)\\n', html, re.IGNORECASE)[0]
                    #html = cPacker().unpack(packed)
                    link = re.findall('<source src="([^"]+)" type="video/mp4">', html)
                    son_url = link[0] + "|Referer=%s" % url
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'cloudy' in url:
                try:
                    media_id = re.findall(r'https?://(?:www\.)?cloudy\.ec/(?:v/|embed\.php\?.*?\bid=)(?P<id>[A-Za-z0-9]+)', url, re.IGNORECASE)[0]
                    page_url = 'https://www.cloudy.ec/embed.php?id=%s&playerPage=1' % media_id
                    page_url = page_url.replace('https','http')
                    oRequest = cRequestHandler(page_url)
                    sHtmlContent = oRequest.request()
                    for match in re.finditer('<source src="([^"]+)" type=\'(.+?)\'>', sHtmlContent):
                        film_quality.append(match.group(2))
                        video_tulpe.append((match.group(1)) + '#User-Agent=' + FF_USER_AGENT)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'daclips.in' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall("(?:file|src): ['|\"](.*?)['|\"],", response)
                    son_url = link[0]
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'dailymotion.com' in url:
                url = url.replace('dailymotion.com/video/', 'dailymotion.com/embed/video/')
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    page = urlKap(url, HTTP_HEADER).result
                    page = page.replace('\\', '')
                    v_tulpe1 = re.findall('"type":"video\/mp4","url":"(.*?x(\d+)\/video.*?mp4.*?)"', page)
                    if v_tulpe1:
                        for v, q in v_tulpe1:
                            video_tulpe.append(v)
                            film_quality.append(q + 'p mp4')
                    v_tulpe = re.findall('"(\d+)"\s*:.+?"url"\s*:\s*"([^"]+)', page)
                    if v_tulpe:
                        for q, v in v_tulpe:
                            video_tulpe.append(v)
                            film_quality.append(q + 'p m3u8')
                except Exception as ex:
                    print ex
                    error = True
					
            if 'datoporn' in url or 'dato.porn' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    packed = re.findall(">(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                    html = cPacker().unpack(packed)
                    for match in re.finditer('file:"([^"]+(mp4|m3u8))"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'http://tiko' in url or 'https://tiko' in url:
                try:
                    def decode_base64(data):
                        missing_padding = len(data) % 4
                        if missing_padding != 0:
                            data += b'='* (4 - missing_padding)
                        return base64.decodestring(data)

                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer': url }
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    host = re.findall('//(.*?)/', url, re.IGNORECASE)[0]
                    link = re.findall('(canli-tv-bot/index.php[^"]+)"', data)[0]
                    url1 = 'http://' + host + '/' + link		
                    req = urllib2.Request(url1, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    Header = 'Referer='+url1+'&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Mobile Safari/537.36'
                    try:
                        link = re.findall('atob\("([^"]+)"', data)[0]
                        dd = (decode_base64(link))
                        son_url = re.findall('source:"([^"]+)",watermark', dd)[0] + '|' + Header
                    except:
                        son_url = re.findall('source:"([^"]+)",watermark', data)[0] + '|' + Header
						
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'crownlive' in url:
                try:
                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer': url }
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    link = re.findall('source: "([^"]+)"', data)[0]
                    Header = 'Referer='+url+'&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Mobile Safari/537.36'
                    son_url = link + '|' + Header
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'channel/watch/' in url:
                try:
                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer': url }
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    link = re.findall('atob\("([^"]+)"', data)[0]
                    dd = (base64.b64decode(link))
                    Header = 'Referer='+url+'&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Mobile Safari/537.36'
                    son_url = re.findall('source:"([^"]+)",watermark', dd)[0] + '|' + Header
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'marsbet' in url:
                try:
                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer': url }
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    link = re.findall("file: '([^']+)',\s+width", data)[0]
                    Header = 'Referer='+url+'&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0'
                    son_url = link + '|' + Header
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'docs.google.com' in url or 'drive.google.com' in url:
                try:
                    media_id = re.findall(r'https?://(?:(?:docs|drive)\.google\.com/(?:uc\?.*?id=|file/d/)|video\.google\.com/get_player\?.*?docid=)(?P<id>[a-zA-Z0-9_-]{20,40})', url, re.IGNORECASE)[0]
                    url = 'https://drive.google.com/file/d/%s/view' % media_id
                    req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0', 'Referer': url})
                    response = urllib2.urlopen(req)
                    sHtmlContent = response.read()
                    Headers = response.headers
                    response.close()			
					
                    c = Headers['Set-Cookie']
                    c2 = re.findall('(?:^|,) *([^;,]+?)=([^;,\/]+?);',c)
                    if c2:
                        cookies = ''
                        for cook in c2:
                            cookies = cookies + cook[0] + '=' + cook[1] + ';'
                    links_parts = re.findall('"fmt_stream_map","(.*?)"', sHtmlContent.decode('unicode-escape'))[0]
                    links_part = re.findall('\\|(.*?),', links_parts)
                    film_quality = []
                    for link_part in links_part:
                        if link_part.encode('utf_8').find('itag=18') > -1:
                            video_link = (link_part + "|User-Agent=" + FF_USER_AGENT + "&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                            video_tulpe.append(video_link)
                            film_quality.append('360p')
                        if link_part.encode('utf_8').find('itag=22') > -1:
                            video_link = (link_part + "|User-Agent=" + FF_USER_AGENT + "&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                            video_tulpe.append(video_link)
                            film_quality.append('720p')
                        if link_part.encode('utf_8').find('itag=37') > -1:
                            video_link = (link_part + "|User-Agent=" + FF_USER_AGENT + "&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                            video_tulpe.append(video_link)
                            film_quality.append('1080p')
                except Exception as ex:
                    print ex
                    error = True
										
            if 'easyvid' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    son_url = re.findall('"([^"]+mp4)"', html)[0]
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'en.iphone-tv.eu/stream' in url:
                try:
                    html = myrequest(url)
                    son_url = re.findall('var streamURL = "(.*?)";', html)[0]
                except:
                    print 'link alinamadi'
                    error = True
					
            if 'estream' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    for match in re.finditer('"([^"]+)" type=\'video\/mp4\' label=\'\d+x(.*?)\'', html):
                        film_quality.append(match.group(2)+'p')
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'facebook.com/video' in url:
                url = url.replace('https', 'http')
                try:
                    page = myrequest(url)
                    params = re.compile('"params","(.*?)"').findall(page)[0]
                    params = params.decode('unicode-escape')
                    params = urllib.unquote(params)
                    urlhd = re.compile('"hd_src":"(.*?)"').findall(params)
                    son_url = urlhd[0].replace('\\', '')
                except Exception as ex:
                    print ex
                    error = True
					
            if 'flashx' in url:
                try:
                    host, media_id = re.findall('(?://|\.)(flashx\.tv)/(?:embed-|dl\?|embed.php\?c=)?([0-9a-zA-Z/-]+)', url, re.IGNORECASE)[0]
                    page_url = 'https://www.flashx.tv/playvid-%s.html' % media_id
                    data = urlKap(page_url).result
                    matches = re.findall("<script type='text/javascript'>(.*?)</script>", data, re.DOTALL | re.MULTILINE)
                    m = ""
                    for n, m in enumerate(matches):
                        if m.startswith("eval"):
                            try:
                                m = cPacker().unpack(m)
                                fake = (re.findall("(\w{40,})", m) == "")
                                if fake:
                                    m = ""
                                else:
                                    break
                            except:
                                m = ""
                    match = m
                    for match in re.finditer('\{file\:"([^"]+)",label:"([^"]+)"', match):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'gorillavid' in url or 'movpod' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall("(?:file|src): ['|\"](.*?)['|\"],", response)
                    son_url = link[0]
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'hqq.tv' in url or 'hqq.watch' in url or 'netu.tv' in url or 'waaw.tv' in url:
                try:
			
                    def GetIp():
                        if (False):
                            sHtmlContent = urlKap('http://hqq.tv/player/ip.php?type=json', FF_USER_AGENT).result
                            ip = re.search('"ip":"([^"]+)"', sHtmlContent, re.DOTALL).group(1)
                        else:
                            import random
                            for x in xrange(1,100):
                                ip = "192.168."
                                ip += ".".join(map(str, (random.randint(0, 255) for _ in range(2))))
                            ip = base64.b64encode(ip)

                        return ip

                    def _decode2(file_url):
                        def K12K(a, typ='b'):
                            codec_a = ["G", "L", "M", "N", "Z", "o", "I", "t", "V", "y", "x", "p", "R", "m", "z", "u",
                                       "D", "7", "W", "v", "Q", "n", "e", "0", "b", "="]
                            codec_b = ["2", "6", "i", "k", "8", "X", "J", "B", "a", "s", "d", "H", "w", "f", "T", "3",
                                       "l", "c", "5", "Y", "g", "1", "4", "9", "U", "A"]
                            if 'd' == typ:
                                tmp = codec_a
                                codec_a = codec_b
                                codec_b = tmp
                            idx = 0
                            while idx < len(codec_a):
                                a = a.replace(codec_a[idx], "___")
                                a = a.replace(codec_b[idx], codec_a[idx])
                                a = a.replace("___", codec_b[idx])
                                idx += 1
                            return a

                        def _xc13(_arg1):
                            _lg27 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
                            _local2 = ""
                            _local3 = [0, 0, 0, 0]
                            _local4 = [0, 0, 0]
                            _local5 = 0
                            while _local5 < len(_arg1):
                                _local6 = 0
                                while _local6 < 4 and (_local5 + _local6) < len(_arg1):
                                    _local3[_local6] = _lg27.find(_arg1[_local5 + _local6])
                                    _local6 += 1
                                _local4[0] = ((_local3[0] << 2) + ((_local3[1] & 48) >> 4))
                                _local4[1] = (((_local3[1] & 15) << 4) + ((_local3[2] & 60) >> 2))
                                _local4[2] = (((_local3[2] & 3) << 6) + _local3[3])

                                _local7 = 0
                                while _local7 < len(_local4):
                                    if _local3[_local7 + 1] == 64:
                                        break
                                    _local2 += chr(_local4[_local7])
                                    _local7 += 1
                                _local5 += 4
                            return _local2

                        return _xc13(K12K(file_url, 'e'))

                    def DecodeAllThePage(html):
                        
                        Maxloop = 10
                        
                        while (Maxloop > 0):
                            Maxloop = Maxloop - 1

                            r = re.search(r'unescape\("([^"]+)"\)', html, re.DOTALL | re.UNICODE)
                            if not r:
                                break
                            
                            tmp = cUtil().unescape(r.group(1))
                            html = html[:r.start()] + tmp + html[r.end():]
                            
                        while (Maxloop > 0):
                            Maxloop = Maxloop - 1

                            r = re.search(r'(;eval\(function\(w,i,s,e\){.+?\)\);)\s*<', html, re.DOTALL | re.UNICODE)
                            if not r:
                                break
                            
                            tmp = data = unwise_process(r.group(1))
                            html = html[:r.start()] + tmp + html[r.end():]

                        return html

                    api_call = ''
					
                    media_id = re.findall('php\?vid=([0-9a-zA-Z/-]+)', url, re.IGNORECASE)[0]
                    player_url = 'http://hqq.tv/player/embed_player.php?vid=%s&autoplay=no' % media_id

                    headers = {'User-Agent': FF_USER_AGENT,
                               #'Host' : 'hqq.tv',
                               'Referer': 'http://hqq.tv/',
                               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                               #'Accept-Encoding':'gzip, deflate, br',
                               #'Content-Type': 'text/html; charset=utf-8'
                               }
							   
							   
                    req = urllib2.Request(player_url,None,headers)
                    try:
                        response = urllib2.urlopen(req)
                        html = response.read()
                        response.close()
                    except urllib2.URLError, e:
                        VSlog(e.read())
                        VSlog(e.reason)
                        html = e.read()

                    Host = 'https://hqq.watch/'

                    data = ''
                    code_crypt = re.search('(;eval\(function\(w,i,s,e\){.+?\)\);)\s*<', html, re.DOTALL)

                    if code_crypt:
                        data = unwise_process(code_crypt.group(1))
                    else:
                        VSlog('prb1')       
                    if data:

                        http_referer = ''
                        _pass = ''
                        
                        iss = GetIp()
                        vid = re.search('var vid *= *"([^"]+)";', data, re.DOTALL).group(1)
                        at = re.search('var at *= *"([^"]+)";', data, re.DOTALL).group(1)
                        r = re.search('var http_referer *= *"([^"]+)";', data, re.DOTALL)
                        if r:
                            http_referer = r.group(1)
                        
                        url2 = Host + "sec/player/embed_player.php?iss=" + iss + "&vid=" + vid + "&at=" + at + "&autoplayed=yes&referer=on&http_referer=" + http_referer + "&pass=" + _pass + "&embed_from=&need_captcha=0"


                        
                        req = urllib2.Request(url2,None,headers)

                        try:
                            response = urllib2.urlopen(req)
                            data = response.read()
                            response.close()
                        except urllib2.URLError, e:
                            VSlog(e.read())
                            VSlog(e.reason)
                            data = e.read()

                        data = urllib.unquote(data)

                        data = DecodeAllThePage(data)

                        at = re.search(r'var\s*at\s*=\s*"([^"]*?)"', data)
                        
                        l = re.search(r'link_1: ([a-zA-Z]+), server_1: ([a-zA-Z]+)', data)
                        
                        vid_server = re.search(r'var ' + l.group(2) + ' = "([^"]+)"', data).group(1)
                        vid_link = re.search(r'var ' + l.group(1) + ' = "([^"]+)"', data).group(1)
                        
                        m = re.search(r' vid: "([a-zA-Z0-9]+)"}', data)
                        if m:
                            id = m.group(1)
                        
                        if vid_server and vid_link and at:

                            get_data = {'server_1': vid_server, 'link_1': vid_link, 'at': at.group(1), 'adb': '0/','b':'1','vid':id}

                            headers['x-requested-with'] = 'XMLHttpRequest'

                            req = urllib2.Request(Host + "/player/get_md5.php?" + urllib.urlencode(get_data),None,headers)
                            try:
                                response = urllib2.urlopen(req)
                            except urllib2.URLError, e:
                                VSlog(str(e.read()))
                                VSlog(str(e.reason))
                                
                            data = response.read()
                            VSlog(data)
                            response.close()

                            file_url = re.search(r'"file"\s*:\s*"([^"]*?)"', data)
                           
                            if file_url:
                                list_url = _decode2(file_url.group(1).replace('\\', ''))

                            list_url = list_url.replace("?socket", ".mp4.m3u8")
                            
                        else:
                            VSlog('prb2')

                    api_call = list_url
                    Header = 'User-Agent=' + FF_USER_AGENT
                    son_url = api_call + '#' + Header
						
                except:
                    print 'link alinamadi'
                    error = True

            if 'izlesene.com' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    response = response.replace('\\', '').replace('%3A', ':').replace('%2F', '/').replace('%3F', '?').replace('%3D', '=').replace('%26', '&')
                    link = re.findall('streamurl":"(.*?mp4.*?)"', response)
                    son_url = link[0]
                except Exception as ex:
                    print ex
                    error = True
					
            if 'letwatch' in url:
                try:
                    html = myrequest(url)
                    son_url = re.findall('file:"(http?:[^"]+flv)', html)[0]
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'liveonlinetv247' in url:
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    html = urlKap(url, HTTP_HEADER).result
                    video_url = re.search('src="(http.*?m3u8[^"]+)"', html, re.IGNORECASE).group(1)
                    son_url = video_url.replace('\\', '')
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if '.m3u8' in url and not 'videotoken.tmgrup.com.tr' in url:
                error = None
                video_tulpe_tmp = []
                url_main = ''
                try:
                    page = urlKap(url).result
                    url_main = '/'.join(url.split('/')[:-1]) + '/'
                    film_quality = re.findall('BANDWIDTH=([0-9]+)', page)
                    if film_quality:
                        video_tulpe_tmp = re.findall('BANDWIDTH=.*\\s(.*)', page)
                        if len(video_tulpe_tmp) > 1:
                            if video_tulpe_tmp[0].find('http') > -1:
                                for tulpe in video_tulpe_tmp:
                                    video_tulpe.append(tulpe.replace('\r', ''))

                            else:
                                for tulpe in video_tulpe_tmp:
                                    video_tulpe.append(url_main + tulpe.replace('\r', ''))
                        else:
                            film_quality = []
                            son_url = url
                    else:
                        son_url = url
                except:
                    son_url = url
					
            if 'mail.ru' in url:
                try:
                    html = urlKap(url).result
                    metadataUrl = re.findall('(?:metadataUrl|metaUrl)":.*?(//my[^"]+)', html)
                    if metadataUrl:
                        nurl = 'https:%s?ver=0.2.123' % metadataUrl[0]
                        page = urlKap(nurl, output='kukili').result
                        video_key = re.findall('video_key[^;]+', page)
                        if video_key:
                            for match in re.finditer('url":"(//cdn[^"]+).+?(\\d+p)', page):
                                video_tulpe.append('http:' + match.group(1) + '|User-Agent=' + FF_USER_AGENT + '&Cookie=' + video_key[0])
                                film_quality.append(match.group(2))
                    else:
                        error = True
                except Exception as ex:
                    print ex
                    error = True
					
            if 'movshare' in url or 'wholecloud' in url:
                try:
                    media_id = re.findall('(?:video/|embed(?:/|\.php)\?(?:v|id)=)([A-Za-z0-9]+)', url, re.IGNORECASE)[0]
                    url = 'http://www.wholecloud.net/video/' + media_id
                    headers = {'User-Agent': FF_USER_AGENT, 'Referer': url}
                    url = url.replace('movshare.net', 'wholecloud.net')
                    html = myrequest(url, headers)
                    token = re.findall('''['"][^'^"]*?(api/toker[^'^"]+?)['"]''', html, re.IGNORECASE)[0]
                    tokenmp4 = re.findall('''['"][^'^"]*?api/toker.php\?f=([^'^"]+?)['"]''', html, re.IGNORECASE)[0]
                    checked = 'http://www.wholecloud.net/' + token
                    var_id = myrequest(checked, headers)
                    video_url = 'http://wholecloud.net/download.php?file=' + tokenmp4
                    req = urllib2.Request(video_url, None, headers)
                    res = urllib2.urlopen(req)
                    son_url = res.geturl()
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'mystream' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    for match in re.finditer('file:"([^"]+)",label:"(\d+)"', html):
                        film_quality.append(match.group(2)+'p')
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'nosvideo' in url or 'noslocker' in url:
                try:
                    host, media_id = re.findall('(?://|\.)(nosvideo.com|noslocker.com)/(?:\?v\=|embed/|.+?\u=)?([0-9a-zA-Z]+)', url, re.IGNORECASE)[0]
                    web_url = 'http://nosvideo.com/embed/%s' % media_id
                    headers = {'User-Agent': FF_USER_AGENT, 'Referer': web_url}
                    html = urlKap(web_url, headers).result
                    html = add_packed_data(html)
                    match = re.search('playlist\s*:\s*"([^"]+)', html)
                    if match:
                        xml = urlKap(match.group(1), headers).result
                        count = 1
                        sources = []
                        streams = set()
                        for match in re.finditer('''file="([^'"]*mp4)''', xml):
                            stream_url = match.group(1)
                            if stream_url not in streams:
                                sources.append(('Source %s' % (count), stream_url))
                                streams.add(stream_url)
                                count += 1
                    son_url = pick_source(sources)# + append_headers(headers)
					
                except Exception as ex:
                    print ex
                    error = True
					
            if 'nowvideo' in url:
                try:
                    headers = {'User-Agent': FF_USER_AGENT}
                    media_id = re.findall('\/video\/([A-Za-z0-9]+)', url, re.IGNORECASE)[0]
                    html = myrequest('http://embed.nowvideo.sx/embed/?v=' + media_id )
                    token = re.findall('''['"][^'^"]*?(api/toker[^'^"]+?)['"]''', html, re.IGNORECASE)[0]
                    checked = 'http://embed.nowvideo.sx/' + token
                    var_id = myrequest(checked, headers)
                    son_url = ''
                    match = re.search('''<source.*?video/mp4''', html, re.DOTALL)
                    if match:
                        links = re.findall('''<source[^>]+?src=['"]([^'^"]+?)['"][^>]+?video/mp4''', match.group(0), re.DOTALL)
                        if links:
                            son_url = random.choice(links)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'ok.ru/videoembed' in url or 'odnoklassniki.ru' in url:
                try:
                    id1 = re.findall('https?://(?:www.)?(?:odnoklassniki|ok).ru/(?:videoembed/|dk\\?cmd=videoPlayerMetadata&mid=)(\\d+)', url)[0]
                    nurl = 'https://ok.ru/videoembed/' + id1
                    html = urlKap(nurl).result
                    data = re.findall('''data-options=['"]([^'^"]+?)['"]''', html)[0]
                    data = data.replace('\\', '').replace('&quot;', '').replace('u0026', '&')
                    hata = re.findall('error":"([^"]+)', data)
                    if hata:
                        error = True
                    else:
                        film_quality = re.findall('{name:(\\w+),url:.*?}', data)
                        video_tulpe = re.findall('{name:\\w+,url:(.*?),seekSchema', data)
                except:
                    error = True
                    print 'link alinamadi'
					
            if 'openload' in url or 'oload' in url:
                try:

                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
					
                    video_urls = []

                    header = {}
                    if "|" in url:
                        url, referer = url.split("|", 1)
                        header = {'Referer': referer}
                    data = urlKap(url, HTTP_HEADER).result

                    try:
                        if "videocontainer" not in data:
                            url = url.replace("/embed/", "/f/")
                            data = urlKap(url, HTTP_HEADER).result

                        text_encode = re.findall('(ﾟωﾟ.*?\(\'\_\'\));', data, re.DOTALL | re.MULTILINE)
                        text_decode = ""
                        for t in text_encode:
                            text_decode += aadecode(t)
							
                        var_r = re.findall("window\.[A-z]+\s*=\s*['\"]([^'\"]+)['\"]", text_decode, re.DOTALL | re.MULTILINE)
                        var_encodes = re.findall('id="%s[^"]*">([^<]+)<' % var_r, data, re.DOTALL | re.MULTILINE)
                        n1, n3, n4 = re.findall("parseInt\('([^']+)',8\)\-(\d+)\+0x4\)/\((\d+)\-0x8\)\)", data, re.DOTALL | re.MULTILINE)[0]
                        n2, n5 = re.findall("parseInt\('([^']+)',8\)\-(\d+);", data, re.DOTALL | re.MULTILINE)[0]
                        op1, op2 = re.findall('\(0x(\d),0x(\d)\);', data, re.DOTALL | re.MULTILINE)[0]
                                
                        videourl = ""
                        for encode in var_encodes:
                            text_decode = ""
                            try:
                                mult = int(op1) * int(op2)
                                rango1 = encode[:mult]
                                decode1 = []
                                for i in range(0, len(rango1), 8):
                                    decode1.append(int(rango1[i:i + 8], 16))
                                rango1 = encode[mult:]
                                j = 0
                                i = 0
                                while i < len(rango1):
                                    index1 = 64
                                    value1 = 0
                                    value2 = 0
                                    value3 = 0
                                    while True:
                                        if (i + 1) >= len(rango1):
                                            index1 = 143
                                        value3 = int(rango1[i:i + 2], 16)
                                        i += 2
                                        data = value3 & 63
                                        value2 += data << value1
                                        value1 += 6
                                        if value3 < index1:
                                            break

                                    value4 = value2 ^ decode1[j % (mult/8)]
                                    value4 ^= ((int(n1, 8) - int(n3) + 4) / (int(n4) - 8)) ^ (int(n2, 8) - int(n5))
                                    value5 = index1 * 2 + 127
                                    for h in range(4):
                                        valorfinal = (value4 >> 8 * h) & (value5)
                                        valorfinal = chr(valorfinal - 1)
                                        if valorfinal != "$":
                                            text_decode += valorfinal
                                    j += 1

                            except:
                                continue

                            videourl = 'https://oload.tv/stream/' + text_decode		
                            dtext = videourl.replace('https', 'http')
                            headers = {'User-Agent': HTTP_HEADER['User-Agent']}
                            req = urllib2.Request(dtext, None, headers)
                            res = urllib2.urlopen(req)
                            videourl = res.geturl()
                            son_url = videourl + '?mime=true'
												
                    except :
                        try:
                            media_id = re.findall('(?:embed|f)/([0-9a-zA-Z-_]+)', url, re.IGNORECASE)[0]
                            API_BASE_URL = 'https://api.openload.co/1'
                            INFO_URL = API_BASE_URL + '/streaming/info'
                            GET_URL = API_BASE_URL + '/streaming/get?file={media_id}'
                                        
                            def get_json(url):
                                result = urlKap(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'Referer': url}).result
                                js_result = re.findall('"url":"(.*?)"', result, re.IGNORECASE)[0]
                                js_result = js_result.replace('\\', '')
                                return js_result
                                        
                            js_data = get_json(GET_URL.format(media_id=media_id))
                            son_url = js_data
							
                        except:
                            try:
                                oRequest = cRequestHandler(url)
                                oRequest.addHeaderEntry('User-Agent',FF_USER_AGENT)
                                sHtmlContent1 = oRequest.request()

                                TabUrl = []
                                sPattern = '<span style="".+?id="([^"]+)">([^<]+)<\/span>'
                                aResult = re.findall(sPattern,sHtmlContent1)
                                if (aResult):
                                    TabUrl = aResult
                                else:
                                    pass
                                    
                                sPattern = '<script src="\/assets\/js\/video-js\/video\.js.+?.js"(.+)*'

                                aResult = re.findall(sPattern,sHtmlContent1, re.DOTALL)
                                if (aResult):
                                    sHtmlContent3 = aResult[0]
                                else:
                                    pass
                                    
                                code = ''
                                maxboucle = 4
                                while (maxboucle > 0):
                                    sHtmlContent3 = CheckCpacker(sHtmlContent3)
                                    sHtmlContent3 = CheckJJDecoder(sHtmlContent3)           
                                    sHtmlContent3 = CheckAADecoder(sHtmlContent3)
                                    
                                    maxboucle = maxboucle - 1
                                 
                                code = sHtmlContent3

                                Coded_url = ''
                                for i in TabUrl:
                                    if len(i[1]) > 30:
                                        Coded_url = i[1]
                                        Item_url = '#' + i[0]

                                code = CleanCode(code,Coded_url)

                                JP = JsParser()
                                Liste_var = []
                                JP.AddHackVar(Item_url,Coded_url)

                                JP.ProcessJS(code,Liste_var)
                                url = JP.GetVarHack("#streamurl")

                                videourl = "https://oload.tv/stream/" + url
                                dtext = videourl.replace('https', 'http')
                                headers = HEADERS
                                req = urllib2.Request(dtext, None, headers)
                                res = urllib2.urlopen(req)
                                videourl = res.geturl()
                                son_url = videourl + '?mime=true'
							
                            except Exception as ex:
                                return ('Visit: https://openload.co/pair', [], [])
							
                except Exception as ex:
                    print ex
                    error = True

            if 'plus.google.com' in url:
                try:
                    request = urllib2.Request(url, None, HEADERS)
                    response = urllib2.urlopen(request).read()
                    response = response.replace('\\', '')
                    for match in re.finditer(r'\[\d+,(\d+),\d+,"([^"]+)"\]', response):
                        film_quality.append(match.group(1))
                        video_tulpe.append(match.group(2).replace('\\', '').replace('u003d', '='))
                except Exception as ex:
                    print ex
                    error = True
					
            if 'radio.de' in url:
                try:
                    page = myrequest(url)
                    if re.match('.*?"stream"', page, re.S):
                        pattern = re.compile('"stream":"(.*?)"')
                        stationStream = pattern.findall(page, re.S)
                        if stationStream:
                            film_quality = []
                            son_url = stationStream[0]
                except:
                    print 'link alinamadi'
                    error = True
					
            if 'rapidvideo' in url:
                try:
                    media_id = re.findall('rapidvideo.(?:org|com)/(?:\\?v=|e/|embed/)([A-z0-9]+)', url, re.IGNORECASE)[0]
                    web_url = 'https://www.rapidvideo.com/e/%s' % media_id
                    request = urllib2.Request(web_url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    if '&q=' in response:
                        for match in re.finditer(r'"(http.*?%s&q=([^"]+))"' % media_id, response):
					        request2 = urllib2.Request(match.group(1), None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
					        response2 = urllib2.urlopen(request2).read()
					        for match2 in re.finditer(r'source src="([^"]+)" type="video/mp4" title="([^"]+)"', response2):
					            film_quality.append(match2.group(2))
					            video_tulpe.append(match2.group(1).replace('\\', ''))
                    else:
                        for match3 in re.finditer('"file":"(http[^"]+)","label":"([^"]+)"', response):
                            film_quality.append(match3.group(2))
                            video_tulpe.append(match3.group(1).replace('\\', ''))
                except Exception as ex:
                    print ex
                    error = True
				
            if 'raptu' in url:
                try:
                    media_id = re.findall('raptu.com/(?:\?v\=|embed/|.+?\u=)?([0-9a-zA-Z]+)', url, re.IGNORECASE)[0]
                    web_url = 'https://www.raptu.com/?v=%s' % media_id
                    request = urllib2.Request(web_url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    response = response.replace('\\', '')
                    for match in re.finditer(r'"file":"([^"]+)","label":"([^"]+)"', response):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1).replace('\\', ''))
                except Exception as ex:
                    print ex
                    error = True
					
            if 'sonicstream' in url:
                try:
                    html = myrequest(url)
                    for match in re.finditer('secury=(.*?)&serverID=(.*?)&getChannel=(\d+)["|&]', html):
                        son_url = 'rtmp://'+ (match.group(2)) +'.futcast11.pro/edge/?' +(match.group(1)) +'/ch'+ (match.group(3))
                except Exception as ex:
                    print ex
					
            if 'sportstream365' in url:
                try:
                    id = re.findall('http://sportstream365/(.*?)/', url, re.IGNORECASE)[0]
                    #tk = 'http://sportstream-365.com/LiveFeed/GetGame?id='+id+'&partner=24'
                    #html = urlKap(tk, referer='http://www.sportstream-365.com/').result
                    #file = re.findall('true,"VI":"(.*?)"',html)[0]
                    #file = re.findall('.*?VI[\'"]*[:,]\s*[\'"]([^\'"]+)[\'"].*',html)[0]
                    link = '"http://213.183.62.42/hls-live/xmlive/_definst_/' + id + '/' + id + '.m3u8":"Server 1", "http://213.183.46.114/hls-live/xmlive/_definst_/' + id + '/' + id + '.m3u8":"Server 2",'
                    for match in re.finditer('"(.*?)":"(.*?)",', link):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1) + '|User-Agent=Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.65 Mobile Safari/537.36')
                except Exception as ex:
                    print ex

            if 'startv.com' in url:
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    html = urlKap(url, HTTP_HEADER).result
                    ol_id = re.search(r'"videoUrl": "([^"]+)"', html, re.IGNORECASE).group(1)
                    html1 = urlKap(ol_id, HTTP_HEADER).result
                    video_url = re.search(r'"hls":"([^"]+)"', html1, re.IGNORECASE).group(1)
                    son_url = video_url.replace('\\', '')
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'streamango' in url or 'streamcherry' in url:
                try:
                    def decode(encoded, code):

                        _0x59b81a = ""
                        k = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
                        k = k[::-1]

                        count = 0

                        for index in range(0, len(encoded) - 1):
                            while count <= len(encoded) - 1:
                                _0x4a2f3a = k.index(encoded[count])
                                count += 1
                                _0x29d5bf = k.index(encoded[count])
                                count += 1
                                _0x3b6833 = k.index(encoded[count])
                                count += 1
                                _0x426d70 = k.index(encoded[count])
                                count += 1

                                _0x2e4782 = ((_0x4a2f3a << 2) | (_0x29d5bf >> 4))
                                _0x2c0540 = (((_0x29d5bf & 15) << 4) | (_0x3b6833 >> 2))
                                _0x5a46ef = ((_0x3b6833 & 3) << 6) | _0x426d70
                                _0x2e4782 = _0x2e4782 ^ code

                                _0x59b81a = str(_0x59b81a) + chr(_0x2e4782)

                                if _0x3b6833 != 64:
                                    _0x59b81a = str(_0x59b81a) + chr(_0x2c0540)
                                if _0x3b6833 != 64:
                                    _0x59b81a = str(_0x59b81a) + chr(_0x5a46ef)

                        return _0x59b81a
				
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    html = urlKap(url, HTTP_HEADER).result
                    video_urls = []

                    matches = re.findall("type:\"video/([^\"]+)\",src:d\('([^']+)',(.*?)\).+?height:(\d+)", html, re.DOTALL | re.MULTILINE)

                    for ext, encoded, code, quality in matches:

                        media_url = decode(encoded, int(code))

                        if not media_url.startswith("http"):
                            media_url = "http:" + media_url
                        video_urls.append(["%sp" % (quality), media_url])

                    video_urls.reverse()
                    for video_url in video_urls:

                        videourl = video_url[1].replace("@", "")
                        headers = HTTP_HEADER
                        req = urllib2.Request(videourl, None, headers)
                        res = urllib2.urlopen(req)
                        vid_url = res.geturl()
                        video_tulpe.append(vid_url)
                        film_quality.append(video_url[0])
					
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'streamcloud' in url:
                try:
                    html = urlKap(url).result
                    postdata = {}
                    for i in re.finditer('<input.*?name="(.*?)".*?value="(.*?)">', html):
                        postdata[i.group(1)] = i.group(2).replace("download1", "download2")
                    keto = myrequest(url, postdata)
                    r = re.search('file: "(.+?)",', keto)
                    if r:
                        son_url = r.group(1)
                except Exception as ex:
                    print ex
                    error = True

            if 'streamin.to' in url:
                if 'embed' not in url:             
                    url = 'http://streamin.to/embed-%s-640x500.html' % url.split('/')[-1]
                try:
                    html = myrequest(url)
                    if re.search('(eval\\(function.*?)\\n', html):
                        packed = re.findall('(eval\\(function.*?)\\n', html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                        son_url = re.findall('file:"([^"]+/v.(?:mp4|flv))"', html)[0]
                    else:
                        error = True
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if '/streaming.video.' in url:
                try:
                    id_list = re.findall('get-location/(.*)/m', url)
                    ids = id_list[0]
                    url1 = 'http://static.video.yandex.ru/get-token/' + ids + '?nc=0.50940609164536'
                    page = myrequest(url1)
                    hash_list = re.findall('token>(.*)</token>', page)
                    hashh = hash_list[0]
                    link1 = url.replace('md5hash', hashh)
                    page2 = myrequest(link1)
                    film_list = re.findall('video-location>(.*)</video-location>', page2)
                    film = film_list[0]
                    son_url = film.replace('&amp;', '&')
                except Exception as ex:
                    print ex
                    error = True
					
            if 'thevideo.me' in url:
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    media_id = re.findall('(?://|\.)thevideo\.me/(?:embed-|download/)?([0-9a-zA-Z]+)', url, re.IGNORECASE)[0]
                    web_url = 'https://thevideo.me/pair?file_code=%s&check' % media_id
                    html = urlKap(web_url, HTTP_HEADER).result
                    key = re.findall('"vt":"(.*?)"', html, re.IGNORECASE)[0]
                    html1 = urlKap(url, HTTP_HEADER).result
                    for match in re.finditer(r'"file":"(.*?)","label":"(\d+p)"', html1):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1)+ '?direct=false&ua=1&vt=' + key)
                except Exception as ex:
                    return ('Visit: https://thevideo.me/pair', [], [])

            if 'thevideos.tv' in url:
                try:
                    r = urlKap(url).result
                    form_values = {}
                    for i in re.finditer('<input.*?name="(.*?)".*?value="(.*?)">', r):
                        form_values[i.group(1)] = i.group(2)
                    html = myrequest(url, postfields=form_values)
                    reobj = re.compile(r"""['"]?file['"]?\s*:\s*['"]([^'"]+)['"][^}]*['"]?label['"]?\s*:\s*['"]([^'"]*)""", re.DOTALL | re.MULTILINE)
                    for match in reobj.finditer(html):
                        video_tulpe.append(match.group(1))
                        film_quality.append(match.group(2))
                except:
                    print 'link alinamadi'
                    error = True
					
            if 'trtarsiv' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall('"(.*?m3u8.*?)"', response)
                    son_url = link[0]
                except Exception as ex:
                    print ex
					
            if 'tune.pk' in url:
                try:
                    UAGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'
                    url = url.replace('https', 'http').replace('http', 'https')
                    url = url.replace('https://tune.pk/player/embed_player.php?vid=', 'https://embed.tune.pk/play/')
                    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    page = urllib2.urlopen(request).read()
                    film_quality = re.findall('"label":(\\d+)', page)
                    vid_tulpe = re.findall('"file":"(.*?)","bitrate', page)
                    video_tulpe = [ vido.replace('\\/', '/')+ '|User-Agent=' + UAGENT for vido in vid_tulpe]
                except Exception as ex:
                    print ex
					
            if 'uptostream' in url:
                try:
                    html = urlKap(url).result
                    try:
                        for i in re.finditer('"src":"([^"]+)","type":"[^"]+","label":"([^"]+)"', html):
                            film_quality.append(i.group(2))
                            video_tulpe.append(i.group(1).replace('\\', ''))
                    except:
                        for i in re.finditer('source src=[\'|"](.*?)[\'|"].*?data-res=[\'|"](.*?)[\'|"]', html):
                            film_quality.append(i.group(2))
                            video_tulpe.append('http:' + i.group(1))
                except:
                    print 'link alinamadi'
                    error = True

            if 'userscloud' in url:
                try:
                    url = url.replace('https', 'http')
                    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',
                     'Connection': 'Close'})
                    page = urllib2.urlopen(request).read()
                    video_url = re.findall('"(http[^"]+mp4)"', page)[0]
                    son_url = video_url
                except Exception as ex:
                    print ex
					
            if 'xsportv' in url or 'betestream' in url or 'queenbet' in url:
                try:
                    html = urlKap(url).result
                    link = re.findall('src="(http://matchandbet.*?)"', html, re.IGNORECASE)[0]
                    req = urllib2.Request(link, None, {'User-agent': 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/30.0.1599.12 Mobile/11A465 Safari/8536.25 (3B92C18B-D9DE-4CB7-A02A-22FD2AF17C8F)', 'Referer': url})
                    response = urllib2.urlopen(req)
                    sHtmlContent = response.read()
                    Headers = response.headers
                    response.close()
                    son_url1 = re.findall("source = '(.*?)'", sHtmlContent, re.IGNORECASE)[0]
                    son_url = son_url1 + "#User-Agent=Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/30.0.1599.12 Mobile/11A465 Safari/8536.25 (3B92C18B-D9DE-4CB7-A02A-22FD2AF17C8F)&Referer=" + link
                    if son_url.startswith("#"):
                        son_url = ''
                    else:
                        son_url = son_url
                except Exception as ex:
                    print ex
					
            if 'zumbet' in url:
                try:
                    html = urlKap(url).result
                    link = re.findall('src="(http://teknolojileri[^"]+)"', html, re.IGNORECASE)[0]
                    req = urllib2.Request(link, None, {'User-agent': 'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/30.0.1599.12 Mobile/11A465 Safari/8536.25 (3B92C18B-D9DE-4CB7-A02A-22FD2AF17C8F)', 'Referer': url})
                    response = urllib2.urlopen(req)
                    sHtmlContent = response.read()
                    response.close()
                    son_url1 = re.findall("source = '(.*?)'", sHtmlContent, re.IGNORECASE)[0]
                    son_url = son_url1 + "#User-Agent=Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/30.0.1599.12 Mobile/11A465 Safari/8536.25 (3B92C18B-D9DE-4CB7-A02A-22FD2AF17C8F)&Referer=" + link
                    if son_url.startswith("#"):
                        son_url = ''
                    else:
                        son_url = son_url
                except Exception as ex:
                    print ex
					
            if 'video.yandex.ru' in url:
                try:
                    page = myrequest(url)
                    r = re.compile('iframe/(.+?)\\?|$').findall(page)
                    url = 'http://static.video.yandex.net/get-token/' + r[0] + '?callback=ct'
                    page = myrequest(url)
                    r2 = re.compile('"token": "(.+?)"').findall(page)
                    url = 'http://streaming.video.yandex.ru/get-location/' + r[0] + '/medium.flv?token=' + r2[0] + '&ref=video.yandex.ru'
                    page1 = myrequest(url)
                    r3 = re.compile('<video-location>(.+?)</video-location>').findall(page1)
                    son_url = r3[0].replace('amp;', '')
                except Exception as ex:
                    print ex
                    error = True
					
            if 'videoraj' in url:
                try:
                    media_id = re.findall('videoraj\.(?:ec|eu|sx|ch|com|to)/(?:v(?:ideo)*/|embed\.php\?id=)([0-9a-z]+)', url, re.IGNORECASE)[0]
                    page_url = 'http://www.videoraj.to/embed.php?id=%s&playerPage=1' % media_id
                    page_url = page_url.replace('https','http')
                    oRequest = cRequestHandler(page_url)
                    sHtmlContent = oRequest.request()
                    for match in re.finditer('<source src="([^"]+)" type=\'(.+?)\'>', sHtmlContent):
                        film_quality.append(match.group(2))
                        video_tulpe.append((match.group(1)) + '#User-Agent=' + FF_USER_AGENT)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if 'videotoken.tmgrup.com.tr' in url:
                try:
                    headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                            'Referer':'http://www.atv.com.tr/webtv/canli-yayin'}
                    req = urllib2.Request(url, None, headers)
                    response = urllib2.urlopen(req)
                    data = response.read()
                    match = re.findall('true,"Url":"(.+?)"', data, re.DOTALL | re.MULTILINE)
                    son_url = '**** '+match[0]
                    if match:
      	              son_url = match[0]
                except:
                    print 'link alinamadi'
                    error = True					
					
            if 'vidmoly' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
                        packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                    for match in re.finditer('"(.*?(m3u8|mp4))"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'vidoza' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    for match in re.finditer('file:"([^"]+)",label:"([^"]+)"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as ex:
                    print ex
                    error = True
				
            if 'vidto.me' in url:
                try:
                    link = myrequest(url)
                    ids = re.compile('<input type="hidden" name="id".*?value="(.*?)">').findall(link)[0]
                    fname = re.compile('<input type="hidden" name="fname".*?value="(.*?)">').findall(link)[0]
                    hash1 = re.compile('<input type="hidden" name="hash".*?value="(.*?)">').findall(link)[0]
                    postdata = {'op': 'download1',
                     'id': ids,
                     'fname': fname,
                     'hash': hash1,
                     'referer': '',
                     'imhuman': 'Proceed to video',
                     'usr_login': ''}
                    sleep_time = int(re.findall('>([0-9])</span> seconds<', link)[0])
                    time.sleep(sleep_time)
                    link = myrequest(url, postdata)
                    for match in re.finditer('file:"(.*?)",label:"(\d+p)"', link):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as ex:
                    print ex
                    error = True

            if 'vidtodo' in url:
                try:
                    url = url.replace('https', 'http')
                    html = urlKap(url).result
                    if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
                        packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                    for match in re.finditer('file: "([^"]+)",\s+label: "([^"]+)"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1)+"#Referer=%s" % url)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'vidup' in url:
                try:
                    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Referer': url}
                    html = urlKap(url, HTTP_HEADER).result
                    key = re.findall("mpri_Key='(.*?)'", html, re.IGNORECASE)[0]
                    packed = urlKap('https://vidup.me/jwv/' + key, HTTP_HEADER).result
                    authKey = re.findall(r"""\|([a-z0-9]{40}[a-z0-9]+?)\|""", packed, re.IGNORECASE)[0]
                    html1 = urlKap(url, HTTP_HEADER).result
                    for match in re.finditer(r'"file":"(.*?)","label":"(\d+p)"', html1):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1)+ '?direct=false&ua=1&vt=' + authKey)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'vidzi' in url:
                try:
                    html = myrequest(url)
                    if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
                        packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                    for match in re.finditer('file: "([^"]+(m3u8|mp4))"', html):
                        film_quality.append(match.group(2).replace('v.mp', 'mp4'))
                        video_tulpe.append(match.group(1).replace('?embed=', ''))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'vk.com' in url:
                url = url.replace('https', 'http').replace('http://www.', 'http://')
                query = url.split('?', 1)[-1]
                query = parse_qs(query)
                api_url = 'http://api.vk.com/method/video.getEmbed?oid=%s&video_id=%s&embed_hash=%s' % (query['oid'][0], query['id'][0], query['hash'][0])
                html = myrequest(api_url)
                hata = re.findall('error_msg":"([^"]+)', html)
                if hata:
                    private_url = 'http://vk.com/al_video.php?act=show_inline&al=1&video=%s_%s' % (query['oid'][0], query['id'][0])
                    html = myrequest(private_url)
                    html = re.sub('\\\\', '', html)
                    html = html.replace('https://', 'http://')
                video_tulpe = re.findall('source src="(https?:[^"]+)', html)
                film_quality = re.findall('(\\d+).mp4\\?extra', html)
				
            if 'vimeo.com' in url:
                try:
                    ids = re.findall('vimeo.com(?:/video)?/(\\d+)', url)[0]
                    url = 'http://player.vimeo.com/video/' + ids + '/config'
                    headers = {'Referer': 'https://vimeo.com/',
                               'Origin': 'https://vimeo.com'}
                    data = urlKap(url,headers).result
                    packed = re.findall('("progressive":\[{.+?}\]})', data, re.IGNORECASE)[0]
                    reg = re.findall(',"url":"(.+?)",.+?"quality":"(.+?)",', packed)
                    for src, quality in reg:
                        video_tulpe.append(src)
                        film_quality.append(quality)
                except:
                    error = True
                    print 'link alinamadi'

            if 'watchers' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
                        packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                    for match in re.finditer('"([^"]+(m3u8|mp4))"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1)+"|Referer=%s" % url)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True

            if 'watchvideo' in url:
                try:
                    url = url.replace('https', 'http')
                    html = myrequest(url)
                    if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
                        packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
                        html = cPacker().unpack(packed)
                    for match in re.finditer('"([^"]+(m3u8|mp4))"', html):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1))
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
				
            if 'web.tv' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall('"src":"(.*?)"', response)
                    son_url = link[0]
                    son_url = son_url.replace('\\', '')
                except Exception as ex:
                    print ex
					
            if 'xvideos' in url:
                try:
                    url1 = url
                    request = urllib2.Request(url1, None, {'User-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1',
                    'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    for i in re.finditer("setVideo(UrlLow|UrlHigh|HLS)\('([^']+)'", response):
                        film_quality.append(i.group(1).replace('UrlLow', 'mp4 LOW').replace('UrlHigh', 'mp4 HIGH').replace('HLS', 'm3u8'))
                        video_tulpe.append(i.group(2))
                except:
                    print 'link alinamadi'
                    error = True
				
            if 'yourporn' in url:
                try:
                    request = urllib2.Request(url, None, {'User-agent': 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
                     'Connection': 'Close'})
                    response = urllib2.urlopen(request).read()
                    link = re.findall("src='([^']+mp4)'", response)
                    son_url1 = link[0]
                    if son_url1.startswith("//"):
                        son_url1 = "http:" + son_url1
                    son_url = son_url1
                except Exception as ex:
                    print ex
				
            if 'youtube' in url:
                gecerli_url = '^\n                 (\n                     (?:https?://)?                                       # http(s):// (optional)\n                     (?:youtu\\.be/|(?:\\w+\\.)?youtube(?:-nocookie)?\\.com/|\n                        tube\\.majestyc\\.net/)                             # the various hostnames, with wildcard subdomains\n                     (?:.*?\\#/)?                                          # handle anchor (#/) redirect urls\n                     (?!view_play_list|my_playlists|artist|playlist)      # ignore playlist URLs\n                     (?:                                                  # the various things that can precede the ID:\n                         (?:(?:v|embed|e)/)                               # v/ or embed/ or e/\n                         |(?:                                             # or the v= param in all its forms\n                             (?:watch(?:_popup)?(?:\\.php)?)?              # preceding watch(_popup|.php) or nothing (like /?v=xxxx)\n                             (?:\\?|\\#!?)                                  # the params delimiter ? or # or #!\n                             (?:.*?&)?                                    # any other preceding param (like /?s=tuff&v=xxxx)\n                             v=\n                         )\n                     )?                                                   # optional -> youtube.com/xxxx is OK\n                 )?                                                       # all until now is optional -> you can pass the naked ID\n                 ([0-9A-Za-z_-]+)                                         # here is it! the YouTube video ID\n                 (?(1).+)?                                                # if we found the ID, everything can follow\n                 $'
                mobj = re.match(gecerli_url, url, re.VERBOSE)
                video_id = mobj.group(2)
                try:
                    try:
                        answer = (urllib2.urlopen(urllib2.Request('http://www.saveitoffline.com/process/?url=https://www.youtube.com/watch?v=' + video_id +'&type=xml')).read())
                        for match in re.finditer('<label>(\d+[^<]+)</label>\s+<url>([^<]+)</url>', answer):
                            film_quality.append(match.group(1))
                            video_tulpe.append(match.group(2))
                    except:
						pass
						
                    gecerli_url = '^\n                 (\n                     (?:https?://)?                                       # http(s):// (optional)\n                     (?:youtu\\.be/|(?:\\w+\\.)?youtube(?:-nocookie)?\\.com/|\n                        tube\\.majestyc\\.net/)                             # the various hostnames, with wildcard subdomains\n                     (?:.*?\\#/)?                                          # handle anchor (#/) redirect urls\n                     (?!view_play_list|my_playlists|artist|playlist)      # ignore playlist URLs\n                     (?:                                                  # the various things that can precede the ID:\n                         (?:(?:v|embed|e)/)                               # v/ or embed/ or e/\n                         |(?:                                             # or the v= param in all its forms\n                             (?:watch(?:_popup)?(?:\\.php)?)?              # preceding watch(_popup|.php) or nothing (like /?v=xxxx)\n                             (?:\\?|\\#!?)                                  # the params delimiter ? or # or #!\n                             (?:.*?&)?                                    # any other preceding param (like /?s=tuff&v=xxxx)\n                             v=\n                         )\n                     )?                                                   # optional -> youtube.com/xxxx is OK\n                 )?                                                       # all until now is optional -> you can pass the naked ID\n                 ([0-9A-Za-z_-]+)                                         # here is it! the YouTube video ID\n                 (?(1).+)?                                                # if we found the ID, everything can follow\n                 $'
                    mobj = re.match(gecerli_url, url, re.VERBOSE)
                    video_id = mobj.group(2)
                    try:
                        if pfy:
                            url = 'https://www.youtube.com/watch?v=' + video_id
                            video = pafy.new(url).streams
                            for s in video:
                                video_tulpe.append(str(s.url))
                                film_quality.append(str(s.resolution + s.extension))
                        else:
                            found = False
                            for el in ['&el=embedded',
                             '&el=detailpage',
                             '&el=vevo',
                             '']:
                                info_url = 'http://www.youtube.com/get_video_info?&video_id=%s%s&ps=default&eurl=&gl=US&hl=en' % (video_id, el)
                                try:
                                    infopage = myrequest(info_url)
                                    videoinfo = parse_qs(infopage)
                                    if ('url_encoded_fmt_stream_map' or 'fmt_url_map') in videoinfo:
                                        found = True
                                        break
                                except Exception as ex:
                                    print ex, 'YT ERROR 1'
                            if found:
                                fmt_value = {'18': '360p',
                                 '22': '720p',
                                 '37': '1080p',
                                 '84': '720p'}
                                if videoinfo.has_key('url_encoded_fmt_stream_map'):
                                    videos = videoinfo['url_encoded_fmt_stream_map'][0].split(',')
                                    for video in videos:
                                        if parse_qs(video)['itag'][0] in fmt_value.keys():
                                            film_quality.append('alt - ' + fmt_value[parse_qs(video)['itag'][0]] + '_' + parse_qs(video)['itag'][0])
                                            video_tulpe.append(parse_qs(video)['url'][0])
                    except Exception as ex:
                        print ex
                        error = True
                except Exception as ex:
                    print ex
                    error = True
					
            if 'youwatch' in url or 'chouhaa' in url:
                try:
                    headers = {'User-Agent': FF_USER_AGENT, 'Referer': url}
                    media_id = re.findall('(?://|\.)(?:youwatch.org|chouhaa.info|voodaith7e.com|youwatch.to)/(?:embed-|)([a-z0-9]+)', url, re.IGNORECASE)[0]
                    page_url = 'http://youwatch.org/embed-%s.html' % media_id
                    html = urlKap(page_url, headers).result
                    html1 = re.findall('<iframe\s+src\s*=\s*"([^"]+)', html, re.IGNORECASE)[0]
                    html2 = urlKap(html1, headers).result
                    for match in re.finditer('file:"([^"]+)",label:"(\d+)"', html2):
                        film_quality.append(match.group(2))
                        video_tulpe.append(match.group(1) + "|Referer=" + html1)
                except Exception as e:
                    print 'link alinamadi : ' + str(e)
                    error = True
					
            if error:
                return (error, video_tulpe, film_quality)
            elif film_quality:
                return (error, video_tulpe, film_quality)
            else:
                return son_url
        except Exception as ex:
            print ex
            print 'html_parser ERROR'