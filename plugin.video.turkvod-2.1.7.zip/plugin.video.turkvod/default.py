# -*- coding: utf-8 -*-
import os
import xbmc, xbmcaddon, xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus
import imp
from resources import TURKvodKodiPrsr

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.turkvod"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
addon = xbmcaddon.Addon(id=addonId)
mac= ""
adultPIN = addon.getSetting("adultPIN")       
adultPINonoff = addon.getSetting( "adultPINonoff" )
serverId = addon.getSetting( "serverId" )	
addonPath = addon.getAddonInfo('path')

TURKVOD_PARSER = TURKvodKodiPrsr.turkvod_parsers()


if addon.getSetting('serverId') == "true":
    server = 'me'
    xbmc.log('server:' + server ) 
else:
    server = 'com'
    xbmc.log('server:' + server ) 

TURKvod_headers = {'User-Agent': 'Mozilla/5.0 TURKvod 8.0'}	
Host = 'http://trvod.' + server + '/80/kodik.php'

yerel_versiyon_dosyasi = os.path.join(os.path.join(addonPath), 'version.xml' )
online_versiyon_dosyasi = "http://trvod.me/repo/version.xml"

def DownloaderClass(url,dest):
    
    dp = xbmcgui.DialogProgress()
    dp.create("TURKvod ZIP DOWNLOADER","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except: 
        percent = 100
        dp.update(percent)
        time.sleep(20)
        dp.close()
    if dp.iscanceled(): 
        dp.close()

def guncellemekontrol(url,loc,aut):
    from resources import ziptools
    xbmc.log('Güncelleme var mı kontrol ediliyor')
    try:
        data = urllib2.urlopen(url).read()
        xbmc.log('Online xml dosyası okunuyor:' + data)
    except:
        data = ""
        xbmc.log('Online xml dosyası okunamadı:' + url )
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        xbmc.log('Yerel xml dosyası okunuyor:' + data2)
    except:
        data2 = ""
        xbmc.log('Yerel xml dosyası okunamadı')

    yeni_versiyon = re.findall("<version>([^<]+)</version>", data)[0]
    yeni_versiyon_no = re.findall("<tag>([^<]+)</tag>", data)[0]
    eski_versiyon = re.findall("<version>([^<]+)</version>", data2)[0]
    eski_versiyon_no = re.findall("<tag>([^<]+)</tag>", data2)[0]
	
    try:
        yeni_ver = int(yeni_versiyon)
        xbmc.log('Online versiyon:' + yeni_versiyon)
        eski_ver = int(eski_versiyon)
        xbmc.log('Yerel versyion:' + eski_versiyon)
    except:
        yeni_versiyon = ""
        xbmc.log('Yerel versyion:' + eski_versiyon )
        xbmc.log('Check fail !@*')
            
    if yeni_versiyon!="" and eski_versiyon!="":
        if (yeni_ver > eski_ver):
            print "*********YENİ SÜRÜM VAR *******"
            extpath = os.path.join(xbmc.translatePath("special://home/addons/")) 
            dest = dataPath + '/lastupdate.zip'                
            UPDATE_URL = 'http://trvod.me/repo/plugin.video.turkvod/plugin.video.turkvod-' + yeni_versiyon_no + '.zip'
            #xbmc.log('GÜNCELLEME BAŞLIYOR:' + UPDATE_URL)
                
            DownloaderClass(UPDATE_URL,dest)  

            from resources import ziptools
            unzipper = ziptools.ziptools()
            unzipper.extract(dest,extpath)
                
            line7 = 'Yeni sürüm yüklendi .....'
            line8 = 'Versiyon no: ' + yeni_versiyon_no 
            xbmcgui.Dialog().ok('TURKvod', line7, line8)
                
            if os.remove( dest ):
                xbmc.log('TEMPORARY ZIP REMOVED')
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmc.sleep(1500)

if addon.getSetting('autoupdate') == "true":
    try:
        guncellemekontrol(online_versiyon_dosyasi, yerel_versiyon_dosyasi, 0)
    except:
        pass
		
def getUrl3(url, mac = None):
        pass#print "Here in Turkvod mac =", mac 
        pass#print "Here in Turkvod url 2 =", url
        sign = '?'
        url = url.strip(' \t\n\r')
        if url.find('?') > -1:
            sign = '&'
        if mac != None:
            security_key = ""
            security_param = ""
            url = url + sign + 'box_mac=' + mac + security_key + security_param
        if url.find('|') > -1:
                parts = url.split('|')
                url = parts[0]
                pass#print "Here in Turkvod url 6 =", url
                cookie = parts[1]
                req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod 8.0 Kodi',
                 'Connection': 'Close',
                 'Cookie': cookie})
        else:
                req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod 8.0 Kodi',
                 'Connection': 'Close'})
        xmlstream = urllib2.urlopen(req).read()
        pass#print "Here in Turkvod xmlstream  =", xmlstream 

        return xmlstream

def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def showContent():
            content = getUrl3(Host, mac)
            start = 0
            i = 0
            while i < 100:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In showContent i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          description = ""
                          pass#print "In showContent i, name =", i, name
                          pass#print "In showContent i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic, description)
                   else:       
                          regexvideo = '<title>(.*?)</title>.*?description>.*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          pass#print "In showContent i, match=", match
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          url = match[0][2]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          description = match[0][1]
                          description = description.replace("]]>", "")
                          pass#print "In showContent i, name 2=", name
                          pass#print "In showContent i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic, description)
                   start = n2+5       
                   i = i+1
            xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, url):
            if "HAKKINDA" in name1:
                if adultPINonoff == "true":			
                     if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 Kodidirect
                                 pin = adultPIN
                                 if pin != "1234":
                                        return
                     else:            
                                 k = xbmc.Keyboard('', 'Adult(18+) PIN') ; k.doModal()
                                 pin = k.getText() if k.isConfirmed() else None
                                 pass#print "Here in search pin =", pin
                                 if pin != "1234":
                                        return
                if adultPINonoff == "false":
				    pass
										
            pass#print "getVideos url =", url
            content = getUrl3(url, mac)
            pass#print "In getVideos content =", content
            start = 0
            i = 0
            while i < 100:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos i, name =", i, name
                          pass#print "In getVideos i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
#                          pass#print "In getVideos i, match=", match
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "") 
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          ##################
                          url = url.replace("TURKvodModul@", "")
                          url = url.replace("@m3u@TURKvod", "")
                          
                          pic = ""
                          pass#print "In getVideos i, name 2=", i, name
                          pass#print "In getVideos i, url 2=", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                   start = n2+5       
                   i = i+1
            xbmcplugin.endOfDirectory(thisPlugin)

def search(url):

            k = xbmc.Keyboard('', 'Search') ; k.doModal()
            query = k.getText() if k.isConfirmed() else None
            pass#print "Here in search query =", query
            #http://trvod.me/80/aramalar/ytube_ara.php?box_mac=00:16:b4:04:df:43&search=adele
            url = url + "?search=" + query
            name = query
            pic = ""
            addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
            xbmcplugin.endOfDirectory(thisPlugin)
            

def getVideos2(name1, url):
        pass#print "getVideos2 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    
            if "/aramalar/" in url:
                   search(url)
            if "www.m3uliste.pw" in url:       
                   getVideos2B(name1, url)
            content = getUrl3(url, mac)
#            pass#print "In getVideos2 content =", content
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos2 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos2 i, name =", i, name
                          pass#print "In getVideos2 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          description = ""
#                          if '<img src="' in ch:
                          try:
                                 regexvideo = '<title>(.*?)</title>.*?description>.*?<img src="(.*?)".*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos2 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][3]
                                 description = match[0][2]
                                 description = description.replace("]]>", "")
#                          else:
                          except:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos2 i, name 2=", name
                          pass#print "In getVideos2 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic, description)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
                    
                   
            xbmcplugin.endOfDirectory(thisPlugin)

def getVideos2B(name1, url):
        pass#print "getVideos2 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    
            if "/aramalar/" in url:
                   search(url)
            content = getUrl3(url, mac)
#            pass#print "In getVideos2 content =", content
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos2 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos2 i, name =", i, name
                          pass#print "In getVideos2 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
#                          if '<img src="' in ch:
                          try:
                                 regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos2 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][2]
#                          else:
                          except:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          url = url.replace("TURKvodModul@", "")
                          url = url.replace("@m3u@TURKvod", "")
                          pass#print "In getVideos2 i, name 2=", name
                          pass#print "In getVideos2 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
                    
                   
            xbmcplugin.endOfDirectory(thisPlugin)


def getVideos3(name1, url):
        pass#print "getVideos3 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    

            pass#print "getVideos3 url =", url
            content = getUrl3(url, mac)
            pass#print "In getVideos3 content =", content
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos3 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          description = ""
                          if '<img src="' in ch:
                                 #regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 regexvideo = '<title>(.*?)</title>.*?description>.*?<img src="(.*?)".*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][3]
                                 description = match[0][2]
                                 description = description.replace("]]>", "")
								 
                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos3 i, name 2=", name
                          pass#print "In getVideos3 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic, description)
                   start = n2+5       
                   i = i+1
                   
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
                    
                   
            xbmcplugin.endOfDirectory(thisPlugin)


def getVideos4(name1, url):
        pass#print "getVideos4 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    

            pass#print "getVideos4 url =", url
            content = getUrl3(url, mac)
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos4 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")                           
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos4 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          description = ""
                          if '<img src="' in ch:
                                 #regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 regexvideo = '<title>(.*?)</title>.*?description>.*?<img src="(.*?)".*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos4 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][3]
                                 description = match[0][2]
                                 description = description.replace("]]>", "")

                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos4 i, name 2=", name
                          pass#print "In getVideos4 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic, description)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
                    

            xbmcplugin.endOfDirectory(thisPlugin)


def getVideos5(name1, url):
        pass#print "getVideos5 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    

            pass#print "getVideos5 url =", url
            content = getUrl3(url, mac)
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos5 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos5 i, name =", i, name
                          pass#print "In getVideos5 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          if '<img src="' in ch:
                                 regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos5 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][2]
                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos5 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos5 i, name 2=", name
                          pass#print "In getVideos5 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":7}, pic)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":7}, pic)
                    

            xbmcplugin.endOfDirectory(thisPlugin)


def getVideos6(name1, url):
        pass#print "getVideos6 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    

            pass#print "getVideos6 url =", url
            content = getUrl3(url, mac)
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos6 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos6 i, name =", i, name
                          pass#print "In getVideos6 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          if '<img src="' in ch:
                                 regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos6 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][2]
                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos6 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos6 i, name 2=", name
                          pass#print "In getVideos6 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":8}, pic)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":8}, pic)
                    
                   
            xbmcplugin.endOfDirectory(thisPlugin)

                
def getVideos7(name1, url):
        pass#print "getVideos7 url =", url
        if url.endswith(".m3u") or "type=m3u" in url:
                  content = getUrl3(url, mac)
#                  pass#print "In getVideos2 content A=", content
                  regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                  match = re.compile(regexcat,re.DOTALL).findall(content)
                  for name, url in match:
                         name = name.replace("\n", "")
                         name = name.replace("\r", "")
                         url = url.replace(" ", "")
                         url = url.replace("\n", "")
                         url = url.replace("\r", "")
                         pic = ""
                         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
                  xbmcplugin.endOfDirectory(thisPlugin)
        else:    

            pass#print "getVideos7 url =", url
            content = getUrl3(url, mac)
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos7 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pic = ""
                          pass#print "In getVideos7 i, name =", i, name
                          pass#print "In getVideos6 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          if '<img src="' in ch:
                                 regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos7 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][2]
                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos7 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          pass#print "In getVideos7 i, name 2=", name
                          pass#print "In getVideos7 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":8}, pic)
                   start = n2+5       
                   i = i+1
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":8}, pic)
                    

            xbmcplugin.endOfDirectory(thisPlugin)

def getVideos8(name, url):
            f = open(url,'r')
            data2 = f.read().replace("\n\n", "")
            f.close()
            pass#print "getVideos3 url =", url
            content = data2
            pass#print "In getVideos3 content =", content
            start = 0
            i = 0
            while i < 1000:
                   n1 = content.find("<channel>", start)
                   if n1 < 0:
                          break
                   n2 = content.find("</channel>", start)
                   if n2 < 0:
                          break
                   ch = content[n1:n2]
                   pass#print "In getVideos3 i, ch =", i, ch
                   if "<stream_url>" in ch: 
                          regexvideo = '<title>(.*?)</title>.*?<stream_url>(.*?)</stream_url>'
                          match = re.compile(regexvideo,re.DOTALL).findall(ch)
                          name = match[0][0]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = match[0][1]
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          url = url.replace("TURKvodModul@", "")
                          url = url.replace("@m3u@TURKvod", "")
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                   else:       
                          name = ""
                          url = ""
                          pic = ""
                          description = ""
                          if '<img src="' in ch:
                                 #regexvideo = '<title>(.*?)</title>.*?<img src="(.*?)".*?<playlist_url>(.*?)</playlist_url>'
                                 regexvideo = '<title>(.*?)</title>.*?description>.*?<img src="(.*?)".*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 1=", match
                                 name = match[0][0]
                                 pic = match[0][1]
                                 url = match[0][3]
                                 description = match[0][2]
                                 description = description.replace("]]>", "")
								 
                          else:
                                 regexvideo = '<title>(.*?)</title>.*?<playlist_url>(.*?)</playlist_url>'
                                 match = re.compile(regexvideo,re.DOTALL).findall(ch)
                                 pass#print "In getVideos3 i, match 2=", match
                                 name = match[0][0]
                                 pic = ""
                                 url = match[0][1]
                          name = name.replace("<![CDATA[", "")
                          name = name.replace("]]>", "")
                          name = name.replace("\n", "")
                          name = name.replace("\r", "")
                          url = url.replace("<![CDATA[", "")
                          url = url.replace("]]>", "")
                          url = url.replace("TURKvodModul@", "")
                          url = url.replace("@m3u@TURKvod", "")
                          pass#print "In getVideos3 i, name 2=", name
                          pass#print "In getVideos3 i, url 2=", url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic, description)
                   start = n2+5       
                   i = i+1
                   
            if "<next_page_url" in content:
                          regexvideo = '<next_page_url.*?http(.*?)\]'
                          match = re.compile(regexvideo,re.DOTALL).findall(content)
                          name = "Next page..."
                          url = "http" + match[0]
                          pic = ""
                          pass#print "In getVideos3 i, name =", i, name
                          pass#print "In getVideos3 i, url =", i, url
                          addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
                    
                   
            xbmcplugin.endOfDirectory(thisPlugin)
			
def playVideo(name, url):
                print "Here in playVideo url =", url
                if url.find('youtube.com') > -1:
                    video_id = url.split('=')
                    if len(video_id) > 1:
                        xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid='+video_id[1]+')')
                else:
                    play_url = TURKVOD_PARSER.get_parsed_link(url)
                    print "play_url =", play_url
					
                    if (play_url == []) or (play_url == ""):
                            play_url = url
                            playVideo2(name, url)
                    else:
                            print "type(play_url) =", type(play_url)

                            if type(play_url) == str:
                                    url = play_url
                                    playVideo2(name, url)
                            elif type(play_url) == tuple:
                                    names = []
                                    urls = []
                                    names = play_url[2]
                                    urls = play_url[1]
                                    if names == []:
                                           pic = ""
                                           url = url
                                           name = name
                                           playVideo2(name, url)
                                    else:       
                                        i = 0
                                        for name in names:
                                           pic = ""
                                           url = urls[i]
                                           i = i+1
                                           addDirectoryItem(name, {"name":name, "url":url, "mode":11}, pic)
                                        xbmcplugin.endOfDirectory(thisPlugin)  
										

def playVideo3(name, url):
           pic = "DefaultFolder.png"
           pass#print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

def playVideo2(name, url):
        if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 Kodidirect
                 pass#print "In playVideo url =", url
                 pic = "DefaultFolder.png"
                 pass#print "Here in playVideo url B=", url
                 li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
                 player = xbmc.Player()
                 player.play(url, li)

        else:  # android or windows Kodi 
            if ".ts" in url: 
                 pass#print "In playVideo url 2=", url
                 import F4mProxy
                 from F4mProxy import f4mProxyHelper
                 player=f4mProxyHelper()
                 player.playF4mLink(url, name, streamtype='TSDOWNLOADER')
            else:
                 pic = "DefaultFolder.png"
                 #pass#print "Here in playVideo url B=", url
                 li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
                 player = xbmc.Player()
                 player.play(url, li)
                 
                 
std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic="", description = ""):
    pass#print "In Turkvod default-py addDirectoryItem parameters =", parameters
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    li.setInfo(type = 'video', infoLabels={'plot': description})
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    pass#print "In Turkvod default-py addDirectoryItem url =", url
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

pass#print "Here in Turkvod start name =", name
pass#print "Here in Turkvod start url =", url
pass#print "Here in Turkvod start mode =", mode

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
                pass#print "Here in Turkvod url 2=", url
		ok = playVideo(name, url)
        elif mode == str(11):
                pass#print "Here in Turkvod url 3=", url
		ok = playVideo2(name, url)
        elif mode == str(12):
                pass#print "Here in Turkvod url 4=", url
		ok = playVideo2(name, url)

	elif mode == str(2):
		if "GUNUN" in name:
		    ok = getVideos3(name, url)
		elif "LOKAL" in name:
		    try:
		        lokal = os.path.join(os.path.join(dataPath), 'TURKvodLokal.xml' )
		        url = lokal
		        ok = getVideos8(name, url)
		    except:
		        lokal = 'http://trvod.' + server + '/80/TURKvodLokal.xml'
		        url = lokal
		        ok = getVideos3(name, url)
		else:
		    ok = getVideos(name, url)	
		
	elif mode == str(3):
		ok = getVideos2(name, url)	

	elif mode == str(4):
		ok = getVideos3(name, url)	
		
	elif mode == str(5):
		ok = getVideos4(name, url)	
	elif mode == str(6):
		ok = getVideos5(name, url)	
	elif mode == str(7):
		ok = getVideos6(name, url)	
	elif mode == str(8):
		ok = getVideos7(name, url)
