package ws.ielshazl.org;

import javax.jws.WebMethod;
import javax.jws.WebService;


@WebService
public class IelshazlCustomer {
	@WebMethod
	public Kunde getCustomer(String customerID){
		
	}
	@WebMethod
	public void setCustomer(Kunde kundeIn){
		
	}

}
